import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_sizes.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../auth/presentation/providers/auth_provider.dart';
import '../../../auth/presentation/providers/pin_provider.dart';
import '../../../subscription_plan/presentation/providers/subscription_provider.dart';

class BoatOwnerProfileScreen extends ConsumerStatefulWidget {
  const BoatOwnerProfileScreen({super.key});

  @override
  ConsumerState<BoatOwnerProfileScreen> createState() => _BoatOwnerProfileScreenState();
}

class _BoatOwnerProfileScreenState extends ConsumerState<BoatOwnerProfileScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(subscriptionProvider.notifier).loadMySubscription();
    });
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authProvider).user;
    final subState = ref.watch(subscriptionProvider);
    final sub = subState.subscription;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('User Profile'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(AppSizes.p16),
        child: Column(
          children: [
            // Profile Card Header
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(AppSizes.p24),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 40,
                    backgroundColor: AppColors.primary.withOpacity(0.1),
                    child: Text(
                      user?.name.substring(0, 1).toUpperCase() ?? 'O',
                      style: AppTextStyles.headlineLarge.copyWith(
                        color: AppColors.primary,
                        fontWeight: FontWeight.bold,
                        fontSize: 32,
                      ),
                    ),
                  ),
                  const SizedBox(height: AppSizes.p12),
                  Text(
                    user?.name ?? 'Boat Owner',
                    style: AppTextStyles.titleMedium.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    user?.email ?? '',
                    style: AppTextStyles.bodyMedium.copyWith(
                      color: AppColors.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: AppSizes.p16),

            // Personal Information
            _buildSection(
              title: 'PERSONAL INFORMATION',
              children: [
                _buildInfoRow(Icons.phone_outlined, 'Phone Number', user?.phone ?? 'Not set'),
                _buildInfoRow(Icons.business_outlined, 'Company Name', user?.companyName ?? 'Not set'),
                _buildInfoRow(Icons.badge_outlined, 'System Role', user?.role ?? 'BOAT_OWNER'),
              ],
            ),
            const SizedBox(height: AppSizes.p16),

            // Subscription Info
            _buildSection(
              title: 'SUBSCRIPTION INFORMATION',
              children: subState.isLoading
                  ? [const Center(child: CircularProgressIndicator())]
                  : [
                      _buildInfoRow(
                        Icons.card_membership_outlined,
                        'Current Plan',
                        sub?.planName ?? 'No Active Plan',
                      ),
                      _buildInfoRow(
                        Icons.date_range_outlined,
                        'Valid Until',
                        sub?.expiryDate != null
                            ? DateFormat('dd-MMM-yyyy').format(sub!.expiryDate!)
                            : 'N/A',
                      ),
                      _buildInfoRow(
                        Icons.timer_outlined,
                        'Remaining',
                        sub != null ? '${sub.remainingDays} Days' : '0 Days',
                      ),
                      _buildInfoRow(
                        Icons.toggle_on_outlined,
                        'Status',
                        sub?.status ?? 'INACTIVE',
                        valueColor: sub?.status.toUpperCase() == 'ACTIVE'
                            ? AppColors.success
                            : AppColors.error,
                      ),
                    ],
            ),
            const SizedBox(height: AppSizes.p16),

            // PIN Lock
            _buildSection(
              title: 'SECURITY',
              children: [
                _buildActionRow(
                  context,
                  icon: Icons.lock_outline_rounded,
                  iconColor: AppColors.warning,
                  label: 'App PIN Lock',
                  subtitle: ref.watch(pinProvider).hasPinSet
                      ? 'PIN lock is enabled (tap to change/disable)'
                      : 'Set a 4-digit PIN for quick app access',
                  onTap: () => _showPinSettingsDialog(context, ref),
                ),
              ],
            ),
            const SizedBox(height: AppSizes.p32),
          ],
        ),
      ),
    );
  }

  Widget _buildSection({required String title, required List<Widget> children}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(AppSizes.p16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: AppTextStyles.labelSmall.copyWith(
              color: AppColors.primary,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.1,
            ),
          ),
          const SizedBox(height: AppSizes.p12),
          ...children,
        ],
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value, {Color? valueColor}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Icon(icon, size: 20, color: AppColors.textHint),
          const SizedBox(width: 12),
          Text(
            label,
            style: AppTextStyles.bodyMedium.copyWith(color: AppColors.textSecondary, fontWeight: FontWeight.w500),
          ),
          const Spacer(),
          Text(
            value,
            style: AppTextStyles.bodyMedium.copyWith(
              fontWeight: FontWeight.bold,
              color: valueColor ?? AppColors.textPrimary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionRow(
    BuildContext context, {
    required IconData icon,
    required Color iconColor,
    required String label,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: iconColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, size: 18, color: iconColor),
            ),
            const SizedBox(width: AppSizes.p12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label,
                      style: AppTextStyles.bodyMedium
                          .copyWith(fontWeight: FontWeight.w600)),
                  Text(subtitle,
                      style: AppTextStyles.bodySmall
                          .copyWith(color: AppColors.textSecondary)),
                ],
              ),
            ),
            const Icon(Icons.chevron_right, size: 18, color: AppColors.textHint),
          ],
        ),
      ),
    );
  }

  // ── PIN settings dialog ───────────────────────────────────────────────────

  Future<void> _showPinSettingsDialog(BuildContext context, WidgetRef ref) async {
    final pinState = ref.read(pinProvider);
    final hasPin = pinState.hasPinSet;

    if (hasPin) {
      await showModalBottomSheet(
        context: context,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        builder: (_) => Padding(
          padding: const EdgeInsets.all(AppSizes.p16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  margin: const EdgeInsets.only(bottom: AppSizes.p12),
                  decoration: BoxDecoration(
                    color: AppColors.border,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              Text('App PIN Lock Settings',
                  style: AppTextStyles.h4),
              const SizedBox(height: AppSizes.p16),
              ListTile(
                leading: const Icon(Icons.edit_outlined, color: AppColors.primary),
                title: const Text('Change PIN'),
                subtitle: const Text('Set a new 4-digit security PIN'),
                onTap: () {
                  Navigator.pop(context);
                  _showSetPinDialog(context, ref);
                },
              ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.lock_open_outlined, color: AppColors.error),
                title: const Text('Disable PIN Lock'),
                subtitle: const Text('Remove PIN entry on launch'),
                onTap: () async {
                  Navigator.pop(context);
                  await ref.read(pinProvider.notifier).clearPin();
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                          content: Text('PIN Lock disabled successfully')),
                    );
                  }
                },
              ),
              const SizedBox(height: AppSizes.p8),
            ],
          ),
        ),
      );
    } else {
      _showSetPinDialog(context, ref);
    }
  }

  void _showSetPinDialog(BuildContext context, WidgetRef ref) {
    final pinCtrl = TextEditingController();
    final confirmCtrl = TextEditingController();
    final formKey = GlobalKey<FormState>();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Set App PIN Lock'),
        content: Form(
          key: formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Enter a 4-digit security PIN to quickly unlock the app.',
                style: TextStyle(fontSize: 13),
              ),
              const SizedBox(height: AppSizes.p16),
              TextFormField(
                controller: pinCtrl,
                keyboardType: TextInputType.number,
                obscureText: true,
                maxLength: 4,
                decoration: const InputDecoration(
                  labelText: 'Enter 4-Digit PIN',
                  border: OutlineInputBorder(),
                  counterText: '',
                ),
                validator: (v) {
                  if (v == null || v.length != 4) return 'PIN must be 4 digits';
                  if (!RegExp(r'^\d{4}$').hasMatch(v)) return 'Only digits allowed';
                  return null;
                },
              ),
              const SizedBox(height: AppSizes.p12),
              TextFormField(
                controller: confirmCtrl,
                keyboardType: TextInputType.number,
                obscureText: true,
                maxLength: 4,
                decoration: const InputDecoration(
                  labelText: 'Confirm PIN',
                  border: OutlineInputBorder(),
                  counterText: '',
                ),
                validator: (v) {
                  if (v != pinCtrl.text) return 'PINs do not match';
                  return null;
                },
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (!formKey.currentState!.validate()) return;
              await ref.read(pinProvider.notifier).setPin(pinCtrl.text);
              if (ctx.mounted) {
                Navigator.pop(ctx);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                      content: Text('PIN Lock configured successfully')),
                );
              }
            },
            child: const Text('Save PIN'),
          ),
        ],
      ),
    );
  }
}
