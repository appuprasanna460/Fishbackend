import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../core/theme/app_sizes.dart';
import '../../../../../core/theme/app_text_styles.dart';
import '../../../../../features/auth/presentation/providers/auth_provider.dart';
import '../../providers/voyage_provider.dart';
import '../../providers/haul_provider.dart';
import '../../widgets/quick_action_card.dart';

class BoatOwnerHomeTab extends ConsumerStatefulWidget {
  const BoatOwnerHomeTab({super.key});

  @override
  ConsumerState<BoatOwnerHomeTab> createState() => _BoatOwnerHomeTabState();
}

class _DashboardMetric extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;

  const _DashboardMetric({
    required this.label,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(AppSizes.p12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.border),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.01),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Icon(icon, color: AppColors.primary, size: 20),
                const SizedBox(width: 4),
              ],
            ),
            const SizedBox(height: AppSizes.p12),
            Text(
              value,
              style: AppTextStyles.headlineMedium.copyWith(
                fontWeight: FontWeight.bold,
                color: AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: AppTextStyles.labelSmall.copyWith(
                color: AppColors.textSecondary,
                fontWeight: FontWeight.w500,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}

class _BoatOwnerHomeTabState extends ConsumerState<BoatOwnerHomeTab> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(voyageProvider.notifier).loadStats();
      ref.read(haulProvider.notifier).fetchRecentHauls();
    });
  }

  Future<void> _onRefresh() async {
    await ref.read(voyageProvider.notifier).loadStats();
    await ref.read(haulProvider.notifier).fetchRecentHauls();
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authProvider).user;
    final voyageState = ref.watch(voyageProvider);
    final haulState = ref.watch(haulProvider);
    final formattedDate = DateFormat('EEEE, d MMMM yyyy').format(DateTime.now());

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'HARBOUR PRO',
              style: AppTextStyles.labelSmall.copyWith(
                color: Colors.white70,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.2,
              ),
            ),
            Text(
              'Welcome, ${user?.name ?? "Owner"}',
              style: AppTextStyles.titleMedium.copyWith(
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_none_outlined, color: Colors.white),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Notifications coming soon')),
              );
            },
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _onRefresh,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(AppSizes.p16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Today, $formattedDate',
                style: AppTextStyles.bodyMedium.copyWith(
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: AppSizes.p16),

              // Metric row
              Text(
                'TODAY AT A GLANCE',
                style: AppTextStyles.labelSmall.copyWith(
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.1,
                ),
              ), 
              const SizedBox(height: AppSizes.p8),
              Row(
                children: [
                  _DashboardMetric(
                    label: 'Active Voyages',
                    value: '${voyageState.activeVoyagesCount}',
                    icon: Icons.directions_boat_outlined,
                  ),
                  const SizedBox(width: AppSizes.p8),
                  _DashboardMetric(
                    label: 'Boats at Sea',
                    value: '${voyageState.boatsAtSeaCount}',
                    icon: Icons.waves_outlined,
                  ),
                  const SizedBox(width: AppSizes.p8),
                  _DashboardMetric(
                    label: "Today's Sales",
                    value: '₹${NumberFormat.compact().format(voyageState.todaySales)}',
                    icon: Icons.monetization_on_outlined,
                  ),
                ],
              ),
              const SizedBox(height: AppSizes.p24),

              // Quick Actions
              Text(
                'QUICK ACTIONS',
                style: AppTextStyles.labelSmall.copyWith(
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.1,
                ),
              ),
              const SizedBox(height: AppSizes.p8),
              GridView.count(
                crossAxisCount: 3,
                crossAxisSpacing: AppSizes.p12,
                mainAxisSpacing: AppSizes.p12,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  QuickActionCard(
                    icon: Icons.add_road,
                    label: 'New Voyage',
                    onTap: () => context.go('/owner/voyages/new'),
                  ),
                  QuickActionCard(
                    icon: Icons.set_meal_outlined,
                    label: 'Catch Entry',
                    onTap: () {
                      context.push('/owner/fishing'); // Assuming tab navigation will handle it or a separate route
                    },
                  ),
                  QuickActionCard(
                    icon: Icons.account_balance_wallet_outlined,
                    label: 'Expenses',
                    onTap: () {
                       context.push('/owner/ledger');
                    },
                  ),
                  QuickActionCard(
                    icon: Icons.local_gas_station_outlined,
                    label: 'Fuel Log',
                    onTap: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Fuel Log Coming Soon in Phase 2')),
                      );
                    },
                  ),
                  QuickActionCard(
                    icon: Icons.people_outline,
                    label: 'Crew Mgmt',
                    onTap: () {
                      context.push('/owner/management'); // Navigate to management
                    },
                  ),
                  QuickActionCard(
                    icon: Icons.map_outlined,
                    label: 'Fishing Grounds',
                    onTap: () {
                      context.push('/owner/fishing-grounds');
                    },
                  ),
                ],
              ),
              const SizedBox(height: AppSizes.p24),
              
              if (haulState.recentHauls.isNotEmpty) ...[
                Text(
                  'RECENT FISHING ACTIVITY',
                  style: AppTextStyles.labelSmall.copyWith(
                    color: AppColors.textSecondary,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.1,
                  ),
                ),
                const SizedBox(height: AppSizes.p8),
                ...haulState.recentHauls.take(3).map((haul) => Card(
                  margin: const EdgeInsets.only(bottom: AppSizes.p8),
                  child: ListTile(
                    leading: const CircleAvatar(
                      backgroundColor: AppColors.primaryLight,
                      child: Icon(Icons.set_meal, color: AppColors.primary),
                    ),
                    title: Text('Haul #${haul.haulNumber} - ${haul.fishingGround}'),
                    subtitle: Text(DateFormat('MMM d, h:mm a').format(haul.startedAt)),
                    trailing: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: haul.status == 'ACTIVE' 
                            ? Colors.blue.shade100 
                            : (haul.status == 'STOPPED' ? Colors.orange.shade100 : Colors.green.shade100),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        haul.status,
                        style: TextStyle(
                          fontSize: 10,
                          color: haul.status == 'ACTIVE' 
                              ? Colors.blue.shade800 
                              : (haul.status == 'STOPPED' ? Colors.orange.shade800 : Colors.green.shade800),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                )).toList(),
                const SizedBox(height: AppSizes.p24),
              ],

              // Alerts
              Text(
                'ALERTS & NOTIFICATIONS',
                style: AppTextStyles.labelSmall.copyWith(
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.1,
                ),
              ),
              const SizedBox(height: AppSizes.p8),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(AppSizes.p16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppColors.border),
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.warning_amber_rounded, color: Colors.orange, size: 20),
                        const SizedBox(width: AppSizes.p12),
                        Expanded(
                          child: Text(
                            'Weather Warning: Storm approaching Chennai coast.',
                            style: AppTextStyles.bodyMedium.copyWith(
                              fontWeight: FontWeight.w600,
                              color: AppColors.textPrimary,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const Divider(height: AppSizes.p24),
                    Row(
                      children: [
                        const Icon(Icons.chat_bubble_outline_rounded, color: AppColors.primary, size: 20),
                        const SizedBox(width: AppSizes.p12),
                        Expanded(
                          child: Text(
                            'New message from Commission Agent.',
                            style: AppTextStyles.bodyMedium.copyWith(
                              color: AppColors.textPrimary,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: AppSizes.p32),
            ],
          ),
        ),
      ),
    );
  }
}
