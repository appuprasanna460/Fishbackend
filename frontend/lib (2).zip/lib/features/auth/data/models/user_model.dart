import '../../domain/entities/user_entity.dart';

class UserModel extends UserEntity {
  const UserModel({
    required super.id,
    required super.name,
    required super.email,
    required super.phone,
    super.companyName,
    required super.role,
    required super.isActive,
    super.agentId,
    super.locationId,
    super.subLocationId,
    super.createdAt,
    super.subscriptionPlanName,
    super.subscriptionStatus,
    super.subscriptionStartDate,
    super.subscriptionEndDate,
    super.subscriptionDurationDays,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    // Helper for parsing int
    int? parseInt(dynamic v) {
      if (v == null) return null;
      if (v is int) return v;
      if (v is num) return v.toInt();
      return null;
    }

    return UserModel(
      id: json['_id'] as String? ?? json['id'] as String? ?? '',
      name: json['name'] as String? ?? '',
      email: json['email'] as String? ?? '',
      phone: json['phone'] as String? ?? '',
      companyName: json['companyName'] as String?,
      role: json['role'] as String? ?? 'STAFF',
      isActive: json['isActive'] as bool? ?? true,
      agentId: json['agentId'] as String?,
      locationId: json['locationId'] is String
          ? json['locationId'] as String
          : (json['locationId'] as Map<String, dynamic>?)?['_id'] as String?,
      subLocationId: json['subLocationId'] is String
          ? json['subLocationId'] as String
          : (json['subLocationId'] as Map<String, dynamic>?)?['_id'] as String?,
      createdAt: json['createdAt'] != null
          ? DateTime.tryParse(json['createdAt'] as String)
          : null,
      // Subscription fields
      subscriptionPlanName: json['subscriptionPlanName'] as String?,
      subscriptionStatus: json['subscriptionStatus'] as String?,
      subscriptionStartDate: json['subscriptionStartDate'] != null
          ? DateTime.tryParse(json['subscriptionStartDate'].toString())
          : null,
      subscriptionEndDate: json['subscriptionEndDate'] != null
          ? DateTime.tryParse(json['subscriptionEndDate'].toString())
          : null,
      subscriptionDurationDays: parseInt(json['subscriptionDurationDays']),
    );
  }

  Map<String, dynamic> toJson() => {
        'name': name,
        'email': email,
        'phone': phone,
        'role': role,
        'isActive': isActive,
        if (companyName != null) 'companyName': companyName,
        if (agentId != null) 'agentId': agentId,
        if (locationId != null) 'locationId': locationId,
        if (subLocationId != null) 'subLocationId': subLocationId,
      };
}
