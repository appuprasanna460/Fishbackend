class UserEntity {
  final String id;
  final String name;
  final String email;
  final String phone;
  final String? companyName;
  final String role;
  final bool isActive;
  final String? agentId;
  final String? locationId;
  final String? subLocationId;
  final DateTime? createdAt;

  // Subscription fields
  final String? subscriptionPlanName;
  final String? subscriptionStatus; // PENDING_APPROVAL, ACTIVE, EXPIRING_SOON, EXPIRED, NONE
  final DateTime? subscriptionStartDate;
  final DateTime? subscriptionEndDate;
  final int? subscriptionDurationDays;

  const UserEntity({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    this.companyName,
    required this.role,
    required this.isActive,
    this.agentId,
    this.locationId,
    this.subLocationId,
    this.createdAt,
    this.subscriptionPlanName,
    this.subscriptionStatus,
    this.subscriptionStartDate,
    this.subscriptionEndDate,
    this.subscriptionDurationDays,
  });

  String get displayRole => role
      .replaceAll('_', ' ')
      .split(' ')
      .map((w) => w[0].toUpperCase() + w.substring(1).toLowerCase())
      .join(' ');

  bool get isSuperAdmin => role == 'SUPER_ADMIN';
  bool get isAgent => role == 'COMMISSION_AGENT';
  bool get isOwner => role == 'BOAT_OWNER';
  bool get isStaff => role == 'STAFF';

  /// Remaining subscription days (0 if expired or no subscription)
  int get remainingSubscriptionDays {
    if (subscriptionEndDate == null) return 0;
    final diff = subscriptionEndDate!.difference(DateTime.now()).inDays;
    return diff < 0 ? 0 : diff;
  }

  bool get isSubscriptionExpired =>
      subscriptionStatus == 'EXPIRED' ||
      (subscriptionEndDate != null && subscriptionEndDate!.isBefore(DateTime.now()));

  bool get isSubscriptionExpiringSoon =>
      subscriptionStatus == 'EXPIRING_SOON' ||
      (remainingSubscriptionDays > 0 && remainingSubscriptionDays <= 3);
}
