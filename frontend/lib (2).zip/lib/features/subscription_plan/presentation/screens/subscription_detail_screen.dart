// lib/features/subscription_plan/presentation/screens/subscription_detail_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../core/theme/app_colors.dart';
import '../providers/subscription_provider.dart';

class SubscriptionDetailScreen extends ConsumerStatefulWidget {
  const SubscriptionDetailScreen({super.key});

  @override
  ConsumerState<SubscriptionDetailScreen> createState() =>
      _SubscriptionDetailScreenState();
}

class _SubscriptionDetailScreenState
    extends ConsumerState<SubscriptionDetailScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(subscriptionProvider.notifier).loadMySubscription();
    });
  }

  Color get _statusColor {
    final status = ref.watch(subscriptionProvider).subscription?.status ?? '';
    switch (status) {
      case 'ACTIVE':
        return const Color(0xFF2ECC71);
      case 'EXPIRING_SOON':
        return const Color(0xFFF39C12);
      case 'EXPIRED':
        return const Color(0xFFE74C3C);
      default:
        return const Color(0xFF95A5A6);
    }
  }

  String _fmtDate(DateTime d) {
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    return '${d.day} ${months[d.month - 1]} ${d.year}';
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(subscriptionProvider);
    final sub = state.subscription;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text(
          'My Subscription',
          style: GoogleFonts.inter(fontWeight: FontWeight.w700),
        ),
        backgroundColor: AppColors.primaryDark,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            onPressed: () =>
                ref.read(subscriptionProvider.notifier).loadMySubscription(),
          ),
        ],
      ),
      body: state.isLoading && sub == null
          ? const Center(child: CircularProgressIndicator())
          : sub == null
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.subscriptions_outlined,
                          size: 64, color: Colors.grey),
                      const SizedBox(height: 16),
                      Text('No subscription found',
                          style: GoogleFonts.inter(
                              fontSize: 16, color: Colors.grey)),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: () => context.push('/plan-selection'),
                        child: const Text('Choose a Plan'),
                      ),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: () => ref
                      .read(subscriptionProvider.notifier)
                      .loadMySubscription(),
                  child: SingleChildScrollView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // ── Status Banner ──────────────────────────────────
                        if (sub.isExpiringSoon)
                          _WarningBanner(
                            color: const Color(0xFFF39C12),
                            icon: Icons.timer_rounded,
                            message:
                                'Your subscription expires in ${sub.remainingDays} day${sub.remainingDays == 1 ? '' : 's'}. Renew now to stay connected.',
                          ),
                        if (sub.isExpired)
                          _WarningBanner(
                            color: const Color(0xFFE74C3C),
                            icon: Icons.cancel_rounded,
                            message:
                                'Your subscription has expired. Request a renewal to continue using the app.',
                          ),

                        const SizedBox(height: 20),

                        // ── Plan Card ──────────────────────────────────────
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(24),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                AppColors.primaryDark,
                                AppColors.primary,
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: [
                              BoxShadow(
                                color: AppColors.primaryDark.withOpacity(0.3),
                                blurRadius: 20,
                                offset: const Offset(0, 8),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  const Icon(Icons.card_membership_rounded,
                                      color: Colors.white70, size: 18),
                                  const SizedBox(width: 8),
                                  Text('SUBSCRIPTION PLAN',
                                      style: GoogleFonts.inter(
                                          fontSize: 11,
                                          color: Colors.white70,
                                          letterSpacing: 1.2)),
                                ],
                              ),
                              const SizedBox(height: 10),
                              Text(
                                sub.planName,
                                style: GoogleFonts.inter(
                                  fontSize: 28,
                                  fontWeight: FontWeight.w800,
                                  color: Colors.white,
                                ),
                              ),
                              if (sub.durationDays != null)
                                Text(
                                  '${sub.durationDays} days plan',
                                  style: GoogleFonts.inter(
                                    fontSize: 14,
                                    color: Colors.white70,
                                  ),
                                ),
                              const SizedBox(height: 20),
                              // Status badge
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 12, vertical: 5),
                                decoration: BoxDecoration(
                                  color: _statusColor.withOpacity(0.25),
                                  borderRadius: BorderRadius.circular(20),
                                  border: Border.all(
                                      color: _statusColor.withOpacity(0.5)),
                                ),
                                child: Text(
                                  sub.status.replaceAll('_', ' '),
                                  style: GoogleFonts.inter(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                    color: _statusColor,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 24),

                        // ── Subscription Dates ─────────────────────────────
                        _DetailCard(
                          title: 'Dates',
                          icon: Icons.calendar_month_rounded,
                          children: [
                            if (sub.startDate != null)
                              _DetailRow(
                                label: 'Start Date',
                                value: _fmtDate(sub.startDate!),
                              ),
                            if (sub.expiryDate != null) ...[
                              const SizedBox(height: 12),
                              _DetailRow(
                                label: 'Expiry Date',
                                value: _fmtDate(sub.expiryDate!),
                                valueColor: _statusColor,
                              ),
                            ],
                          ],
                        ),

                        const SizedBox(height: 16),

                        // ── Remaining Days ─────────────────────────────────
                        if (sub.durationDays != null &&
                            sub.durationDays! > 0) ...[
                          _DetailCard(
                            title: 'Subscription Progress',
                            icon: Icons.timelapse_rounded,
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text('Remaining',
                                      style: GoogleFonts.inter(
                                          fontSize: 13,
                                          color: AppColors.textSecondary)),
                                  Text(
                                    '${sub.remainingDays} / ${sub.durationDays} days',
                                    style: GoogleFonts.inter(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w700,
                                      color: _statusColor,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),
                              ClipRRect(
                                borderRadius: BorderRadius.circular(6),
                                child: LinearProgressIndicator(
                                  value: (sub.remainingDays / sub.durationDays!)
                                      .clamp(0.0, 1.0),
                                  backgroundColor:
                                      _statusColor.withOpacity(0.1),
                                  valueColor:
                                      AlwaysStoppedAnimation<Color>(_statusColor),
                                  minHeight: 10,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),
                        ],

                        // ── Pending Renewal ────────────────────────────────
                        if (sub.hasPendingRenewal) ...[
                          Container(
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: Colors.blue.shade50,
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                  color: Colors.blue.shade200),
                            ),
                            child: Row(children: [
                              const Icon(Icons.pending_actions_rounded,
                                  color: Colors.blue),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('Renewal Request Pending',
                                        style: GoogleFonts.inter(
                                          fontWeight: FontWeight.w700,
                                          color: Colors.blue.shade800,
                                        )),
                                    Text(
                                      '${sub.pendingRenewal!.requestedPlanName} (${sub.pendingRenewal!.requestedDurationDays} days)',
                                      style: GoogleFonts.inter(
                                          fontSize: 12,
                                          color: Colors.blue.shade600),
                                    ),
                                  ],
                                ),
                              ),
                            ]),
                          ),
                          const SizedBox(height: 16),
                        ],

                        // ── Renew / Recharge CTA ───────────────────────────
                        if (!sub.hasPendingRenewal) ...[
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton.icon(
                              onPressed: () =>
                                  context.push('/plan-selection'),
                              icon: const Icon(Icons.refresh_rounded),
                              label: Text(
                                sub.isExpired
                                    ? 'Recharge Subscription'
                                    : 'Renew / Upgrade Plan',
                                style: GoogleFonts.inter(
                                    fontWeight: FontWeight.w700),
                              ),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: _statusColor,
                                foregroundColor: Colors.white,
                                padding:
                                    const EdgeInsets.symmetric(vertical: 16),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                elevation: 4,
                              ),
                            ),
                          ),
                        ],

                        const SizedBox(height: 40),
                      ],
                    ),
                  ),
                ),
    );
  }
}

class _WarningBanner extends StatelessWidget {
  final Color color;
  final IconData icon;
  final String message;

  const _WarningBanner(
      {required this.color, required this.icon, required this.message});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      margin: const EdgeInsets.only(bottom: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.4)),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(message,
                style: GoogleFonts.inter(fontSize: 13, color: color)),
          ),
        ],
      ),
    );
  }
}

class _DetailCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final List<Widget> children;

  const _DetailCard(
      {required this.title, required this.icon, required this.children});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 12,
              offset: const Offset(0, 4)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Icon(icon, size: 16, color: AppColors.primary),
            const SizedBox(width: 8),
            Text(title,
                style: GoogleFonts.inter(
                    fontWeight: FontWeight.w700,
                    fontSize: 14,
                    color: AppColors.textPrimary)),
          ]),
          const SizedBox(height: 14),
          ...children,
        ],
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final String label;
  final String value;
  final Color? valueColor;

  const _DetailRow({required this.label, required this.value, this.valueColor});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label,
            style: GoogleFonts.inter(
                fontSize: 13, color: AppColors.textSecondary)),
        Text(value,
            style: GoogleFonts.inter(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: valueColor ?? AppColors.textPrimary,
            )),
      ],
    );
  }
}
