import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  // ============================================================
  // AZUL BLUE — PRIMARY BRAND PALETTE
  // ============================================================

  // Main brand blue - Updated to #0052CC
  static const Color primary = Color(0xFF0052CC);

  // Lighter variant - Calculated from #0052CC
  static const Color primaryLight = Color(0xFF3B7BEE);

  // Darker / deeper variant - Calculated from #0052CC
  static const Color primaryDark = Color(0xFF003D99);

  // Light backgrounds - Updated to match new blue
  static const Color primarySurface = Color(0xFFEBF2FF);
  static const Color primaryContainer = Color(0xFFD6E4FF);

  // ============================================================
  // SECONDARY - Updated to match primary
  // ============================================================

  static const Color secondary = Color(0xFF0052CC);
  static const Color secondaryLight = Color(0xFF3B7BEE);
  static const Color secondaryDark = Color(0xFF003D99);
  static const Color secondarySurface = Color(0xFFEBF2FF);

  // ============================================================
  // ACCENT - Complementary warm colors for #0052CC
  // ============================================================

  static const Color accent = Color(0xFFFF6B35);
  static const Color accentLight = Color(0xFFFFA07A);
  static const Color accentSurface = Color(0xFFFFF0E8);

  // ============================================================
  // BACKGROUND
  // ============================================================

  static const Color background = Color(0xFFF7F9FC);
  static const Color backgroundDark = Color(0xFF0F172A);
  static const Color surface = Colors.white;
  static const Color surfaceVariant = Color(0xFFF1F4F9);
  static const Color cardBackground = Colors.white;

  // ============================================================
  // GRADIENTS - Updated with new blue
  // ============================================================

  static const List<Color> primaryGradient = [
    Color(0xFF0052CC),
    Color(0xFF003D99),
  ];

  static const List<Color> loginGradient = [
    Color(0xFF0052CC),
    Color(0xFF003D99),
  ];

  static const List<Color> oceanGradient = [
    Color(0xFF0052CC),
    Color(0xFF003D99),
  ];

  // ============================================================
  // TEXT
  // ============================================================

  static const Color textPrimary = Color(0xFF0F172A);
  static const Color textSecondary = Color(0xFF475569);
  static const Color textHint = Color(0xFF94A3B8);
  static const Color textDisabled = Color(0xFFCBD5E1);

  // White text on Cobalt Blue
  static const Color textOnPrimary = Colors.white;
  static const Color textOnDark = Color(0xFFF8FAFC);

  // ============================================================
  // BORDERS
  // ============================================================

  static const Color border = Color(0xFFE2E8F0);
  static const Color borderFocused = Color(0xFF0052CC);
  static const Color divider = Color(0xFFE2E8F0);

  // ============================================================
  // STATUS COLORS - Refined for better harmony
  // ============================================================

  static const Color error = Color(0xFFE3495B);
  static const Color danger = Color(0xFFE3495B);
  static const Color errorLight = Color(0xFFFDE8EA);

  static const Color success = Color(0xFF36B37E);
  static const Color successLight = Color(0xFFE3FCEF);
  static const Color successSurface = Color(0xFFE3FCEF);

  static const Color errorSurface = Color(0xFFFDE8EA);

  static const Color warning = Color(0xFFFFAB00);
  static const Color warningLight = Color(0xFFFFF4E5);

  static const Color info = Color(0xFF00A3BF);
  static const Color infoLight = Color(0xFFE0F7FA);

  // ============================================================
  // ROLE COLORS - Updated
  // ============================================================

  static const Color roleSuperAdmin = Color(0xFF003D99);
  static const Color roleAgent = Color(0xFF0052CC);
  static const Color roleStaff = Color(0xFF3B7BEE);
  static const Color roleBuyer = Color(0xFFE3495B);
  static const Color roleOwner = Color(0xFF0052CC);

  // ============================================================
  // STATUS
  // ============================================================

  static const Color statusActive = Color(0xFF36B37E);
  static const Color statusInactive = Color(0xFF6B7785);
  static const Color statusPending = Color(0xFFFFAB00);
  static const Color statusPaid = Color(0xFF0052CC);
  static const Color statusOverdue = Color(0xFFE3495B);

  // ============================================================
  // GLASS
  // ============================================================

  static const Color glassBackground = Color(0x1AFFFFFF);
  static const Color glassBorder = Color(0x33FFFFFF);

  // ============================================================
  // SHADOWS
  // ============================================================

  static const Color shadow = Color(0x0D000000);
  static const Color shadowMedium = Color(0x1A000000);

  static const Color shadowPurple = Color(0x260052CC);
  static const Color shadowBlue = Color(0x260052CC);
}