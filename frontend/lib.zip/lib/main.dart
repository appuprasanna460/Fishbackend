import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'core/theme/app_theme.dart';
import 'router/app_router.dart';
import 'core/splash/splash_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ProviderScope(child: FishMarketApp()));
}

class FishMarketApp extends ConsumerStatefulWidget {
  const FishMarketApp({super.key});

  @override
  ConsumerState<FishMarketApp> createState() => _FishMarketAppState();
}

class _FishMarketAppState extends ConsumerState<FishMarketApp>
    with SingleTickerProviderStateMixin {
  bool _showSplash = true;

  @override
  void initState() {
    super.initState();

    // Show splash for 4 seconds, then transition to main app
    Future.delayed(const Duration(milliseconds: 4000), () {
      if (mounted) {
        setState(() => _showSplash = false);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_showSplash) {
      return MaterialApp(
        title: 'Fish Market Management',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.lightTheme,
        home: const SplashScreen(),
      );
    }

    final router = ref.watch(appRouterProvider);
    return MaterialApp.router(
      title: 'Fish Market Management',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      routerConfig: router,
    );
  }
}
