import 'package:dio/dio.dart';
import '../constants/api_constants.dart';
import '../utils/secure_storage.dart';

class DioClient {
  late final Dio dio;

  DioClient() {
    dio = Dio(
      BaseOptions(
        baseUrl: ApiConstants.baseUrl,
        connectTimeout: const Duration(
          milliseconds: ApiConstants.connectTimeout,
        ),
        receiveTimeout: const Duration(
          milliseconds: ApiConstants.receiveTimeout,
        ),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        validateStatus: (status) {
          return status != null && status >= 200 && status < 300;
        },
      ),
    );

    // Add interceptors
    dio.interceptors.add(_TokenInterceptor());

    // ✅ Enable detailed logging
    dio.interceptors.add(
      LogInterceptor(
        requestBody: true,
        responseBody: true,
        error: true,
        logPrint: (obj) => print('🔵 DIO: $obj'),
      ),
    );

    // Add error handling interceptor
    dio.interceptors.add(
      InterceptorsWrapper(
        onError: (error, handler) {
          print('🔴 DIO Error: ${error.message}');
          print('🔴 Response: ${error.response?.data}');
          print('🔴 Status: ${error.response?.statusCode}');

          // Return a more user-friendly error
          if (error.type == DioExceptionType.connectionTimeout ||
              error.type == DioExceptionType.sendTimeout ||
              error.type == DioExceptionType.receiveTimeout) {
            return handler.reject(
              DioException(
                requestOptions: error.requestOptions,
                error: 'Connection timeout. Please check your network.',
              ),
            );
          }

          if (error.response?.statusCode == 401) {
            SecureStorage.deleteAll();
          }

          handler.next(error);
        },
      ),
    );
  }
}

class _TokenInterceptor extends Interceptor {
  @override
  void onRequest(
    RequestOptions options,
    RequestInterceptorHandler handler,
  ) async {
    try {
      final token = await SecureStorage.getToken();
      if (token != null && token.isNotEmpty) {
        options.headers['Authorization'] = 'Bearer $token';
        print('🔑 Token added to request');
      } else {
        print('⚠️ No token found');
      }
    } catch (e) {
      print('❌ Error getting token: $e');
    }
    handler.next(options);
  }

  @override
  void onError(DioException err, ErrorInterceptorHandler handler) {
    if (err.response?.statusCode == 401) {
      SecureStorage.deleteAll();
    }
    handler.next(err);
  }
}
