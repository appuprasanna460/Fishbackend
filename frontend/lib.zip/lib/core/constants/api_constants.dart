// lib/core/constants/api_constants.dart
class ApiConstants {
  // Use your machine's IP for physical device testing
  static const String baseUrl = 'http://127.0.0.1:5000/api';

  static const String apiBase = '/api';
  static const int connectTimeout = 15000;
  static const int receiveTimeout = 15000;

  // Auth
  static const String login = '/api/auth/login';
  static const String logout = '/api/auth/logout';
  static const String profile = '/api/auth/profile';
  // ✅ NEW: Self-registration
  static const String register = '/api/auth/register';

  // Locations
  static const String locations = '/api/locations';

  // Users
  static const String users = '/api/users';

  // Boats
  static const String boats = '/api/boats';

  // Fish
  static const String fish = '/api/fish';

  // Billing
  static const String bills = '/api/bills';

  // Bookings - NEW
  static const String bookings = '/api/bookings';

  // Ledger
  static const String ledger = '/api/ledger';

  // Tracking
  static const String tracking = '/api/tracking';

  // Reports
  static const String reports = '/api/reports';
  static const String revenueReport = '/api/reports/revenue';
  static const String revenueByFish = '/api/reports/revenue-by-fish';
  static const String revenueByLocation = '/api/reports/revenue-by-location';
  static const String billsSummary = '/api/reports/bills-summary';
  static const String auditLogs = '/api/reports/audit-logs';
  static const String dashboardSummary = '/api/reports/dashboard-summary';

  // Fish Buyer Bills
  static const String fishBuyerBills = '/api/fish-buyer-bills';
  static const String fishBuyerBillsByAgent = '/api/fish-buyer-bills/agent';

  // ── Boat Owner Module ──────────────────────────────────────────────────────
  static const String boatOwnerBase = '/api/boat-owner';
  static const String boatOwnerDashboard = '/api/boat-owner/dashboard';
  static const String boatOwnerBills = '/api/boat-owner/bills';
  static const String boatOwnerLedger = '/api/boat-owner/ledger';
  static const String boatOwnerLedgerSummary = '/api/boat-owner/ledger/summary';
  static const String boatOwnerFishingLocations =
      '/api/boat-owner/fishing-locations';
  static const String boatOwnerProfile = '/api/boat-owner/profile';

  // Invoice Templates
  static const String invoiceTemplates = '/api/templates';
  static const String invoiceTemplatesActive = '/api/templates/active';
  static const String invoiceTemplatesAll = '/api/templates/all';
  static const String invoiceTemplateById = '/api/templates/{id}';
  static const String invoiceTemplateToggle = '/api/templates/{id}/toggle';

  // ✅ NEW: Harbours
  static const String harbours = '/api/harbours';

  // ✅ NEW: Registration Notifications (Super Admin)
  static const String notifications = '/api/notifications';
  static const String approveRegistration = '/api/notifications/{id}/approve';
  static const String rejectRegistration = '/api/notifications/{id}/reject';
}
