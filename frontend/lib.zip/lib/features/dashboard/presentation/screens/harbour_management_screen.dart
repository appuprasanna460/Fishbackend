import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:dio/dio.dart';
import '../../../../core/constants/api_constants.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/network/dio_client.dart';
import '../../../auth/presentation/providers/auth_provider.dart';

// ─── Model ────────────────────────────────────────────────────────────────────

class HarbourItem {
  final String id;
  final String name;
  final bool isActive;

  const HarbourItem({
    required this.id,
    required this.name,
    required this.isActive,
  });

  factory HarbourItem.fromJson(Map<String, dynamic> json) => HarbourItem(
        id: json['_id'] as String,
        name: json['name'] as String,
        isActive: json['isActive'] as bool? ?? true,
      );
}

// ─── State ────────────────────────────────────────────────────────────────────

class _HarbourState {
  final List<HarbourItem> harbours;
  final bool isLoading;
  final String? error;

  const _HarbourState({
    this.harbours = const [],
    this.isLoading = false,
    this.error,
  });

  _HarbourState copyWith(
          {List<HarbourItem>? harbours,
          bool? isLoading,
          String? error,
          bool clearError = false}) =>
      _HarbourState(
        harbours: harbours ?? this.harbours,
        isLoading: isLoading ?? this.isLoading,
        error: clearError ? null : (error ?? this.error),
      );
}

// ─── Notifier ─────────────────────────────────────────────────────────────────

final _harbourMgmtProvider =
    StateNotifierProvider.autoDispose<_HarbourNotifier, _HarbourState>(
        (ref) => _HarbourNotifier(ref.read(dioClientProvider)));

class _HarbourNotifier extends StateNotifier<_HarbourState> {
  final DioClient _client;
  _HarbourNotifier(this._client) : super(const _HarbourState()) {
    load();
  }

  Future<void> load() async {
    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final res = await _client.dio.get(ApiConstants.harbours);
      final data = res.data['data'] as List? ?? [];
      final list = data
          .map((e) => HarbourItem.fromJson(e as Map<String, dynamic>))
          .toList();
      state = state.copyWith(harbours: list, isLoading: false);
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }

  Future<bool> create(String name) async {
    try {
      await _client.dio.post(ApiConstants.harbours, data: {'name': name});
      await load();
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<bool> update(String id, String name, bool isActive) async {
    try {
      await _client.dio.put(
        '${ApiConstants.harbours}/$id',
        data: {'name': name, 'isActive': isActive},
      );
      await load();
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<bool> delete(String id) async {
    try {
      await _client.dio.delete('${ApiConstants.harbours}/$id');
      await load();
      return true;
    } catch (e) {
      return false;
    }
  }
}

// ─── Screen ───────────────────────────────────────────────────────────────────

class HarbourManagementScreen extends ConsumerStatefulWidget {
  const HarbourManagementScreen({super.key});

  @override
  ConsumerState<HarbourManagementScreen> createState() =>
      _HarbourManagementScreenState();
}

class _HarbourManagementScreenState
    extends ConsumerState<HarbourManagementScreen> {
  @override
  Widget build(BuildContext context) {
    final state = ref.watch(_harbourMgmtProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [AppColors.primaryDark, AppColors.primary],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        title: Text(
          'Harbour Management',
          style: GoogleFonts.inter(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        leading: IconButton(
          icon:
              const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white),
          onPressed: () => context.pop(),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: Colors.white),
            onPressed: () =>
                ref.read(_harbourMgmtProvider.notifier).load(),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddDialog(context),
        backgroundColor: AppColors.primary,
        icon: const Icon(Icons.add_rounded, color: Colors.white),
        label: Text(
          'Add Harbour',
          style: GoogleFonts.inter(
              color: Colors.white, fontWeight: FontWeight.w600),
        ),
      ),
      body: state.isLoading
          ? const Center(child: CircularProgressIndicator())
          : state.error != null
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.error_outline,
                          size: 48, color: AppColors.danger),
                      const SizedBox(height: 12),
                      Text(state.error!,
                          style: GoogleFonts.inter(
                              color: AppColors.textSecondary)),
                      const SizedBox(height: 16),
                      ElevatedButton.icon(
                        onPressed: () =>
                            ref.read(_harbourMgmtProvider.notifier).load(),
                        icon: const Icon(Icons.refresh_rounded),
                        label: const Text('Retry'),
                      ),
                    ],
                  ),
                )
              : state.harbours.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.anchor_rounded,
                              size: 56, color: AppColors.textSecondary),
                          const SizedBox(height: 12),
                          Text(
                            'No harbours yet',
                            style: GoogleFonts.inter(
                              fontSize: 18,
                              color: AppColors.textSecondary,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Tap the + button to add your first harbour.',
                            style: GoogleFonts.inter(
                                color: AppColors.textSecondary, fontSize: 13),
                          ),
                        ],
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: state.harbours.length,
                      itemBuilder: (ctx, i) {
                        final h = state.harbours[i];
                        return _HarbourCard(
                          harbour: h,
                          onEdit: () => _showEditDialog(context, h),
                          onToggle: () => ref
                              .read(_harbourMgmtProvider.notifier)
                              .update(h.id, h.name, !h.isActive),
                          onDelete: () => _confirmDelete(context, h),
                        );
                      },
                    ),
    );
  }

  Future<void> _showAddDialog(BuildContext context) async {
    final ctrl = TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => _HarbourDialog(
        title: 'Add Harbour',
        controller: ctrl,
        onConfirm: () => Navigator.of(ctx).pop(true),
      ),
    );
    if (confirmed == true && ctrl.text.trim().isNotEmpty) {
      final ok = await ref
          .read(_harbourMgmtProvider.notifier)
          .create(ctrl.text.trim());
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(ok
              ? 'Harbour added successfully'
              : 'Failed to add harbour'),
          backgroundColor: ok ? Colors.green : AppColors.danger,
        ));
      }
    }
  }

  Future<void> _showEditDialog(BuildContext context, HarbourItem h) async {
    final ctrl = TextEditingController(text: h.name);
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => _HarbourDialog(
        title: 'Edit Harbour',
        controller: ctrl,
        onConfirm: () => Navigator.of(ctx).pop(true),
      ),
    );
    if (confirmed == true && ctrl.text.trim().isNotEmpty) {
      final ok = await ref
          .read(_harbourMgmtProvider.notifier)
          .update(h.id, ctrl.text.trim(), h.isActive);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(
              ok ? 'Harbour updated' : 'Failed to update harbour'),
          backgroundColor: ok ? Colors.green : AppColors.danger,
        ));
      }
    }
  }

  Future<void> _confirmDelete(BuildContext context, HarbourItem h) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('Delete Harbour',
            style: GoogleFonts.inter(fontWeight: FontWeight.bold)),
        content: Text(
          'Delete "${h.name}"? This action cannot be undone.',
          style: GoogleFonts.inter(),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(ctx).pop(false),
              child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.danger),
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Delete',
                style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      final ok = await ref
          .read(_harbourMgmtProvider.notifier)
          .delete(h.id);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(
              ok ? 'Harbour deleted' : 'Failed to delete harbour'),
          backgroundColor: ok ? Colors.green : AppColors.danger,
        ));
      }
    }
  }
}

// ─── Sub-widgets ──────────────────────────────────────────────────────────────

class _HarbourCard extends StatelessWidget {
  final HarbourItem harbour;
  final VoidCallback onEdit;
  final VoidCallback onToggle;
  final VoidCallback onDelete;

  const _HarbourCard({
    required this.harbour,
    required this.onEdit,
    required this.onToggle,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withOpacity(0.07),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: harbour.isActive
                    ? AppColors.primary.withOpacity(0.1)
                    : Colors.grey.shade200,
              ),
              child: Icon(
                Icons.anchor_rounded,
                color: harbour.isActive
                    ? AppColors.primary
                    : Colors.grey,
                size: 22,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    harbour.name,
                    style: GoogleFonts.inter(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: harbour.isActive
                          ? Colors.green.shade50
                          : Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      harbour.isActive ? 'Active' : 'Inactive',
                      style: GoogleFonts.inter(
                        fontSize: 11,
                        color: harbour.isActive
                            ? Colors.green.shade700
                            : Colors.grey,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            // Toggle
            IconButton(
              onPressed: onToggle,
              icon: Icon(
                harbour.isActive
                    ? Icons.toggle_on_rounded
                    : Icons.toggle_off_rounded,
                color: harbour.isActive
                    ? AppColors.primary
                    : Colors.grey,
                size: 32,
              ),
              tooltip: harbour.isActive ? 'Deactivate' : 'Activate',
            ),
            // Edit
            IconButton(
              onPressed: onEdit,
              icon: const Icon(Icons.edit_rounded,
                  color: AppColors.primary, size: 20),
            ),
            // Delete
            IconButton(
              onPressed: onDelete,
              icon: const Icon(Icons.delete_rounded,
                  color: AppColors.danger, size: 20),
            ),
          ],
        ),
      ),
    );
  }
}

class _HarbourDialog extends StatelessWidget {
  final String title;
  final TextEditingController controller;
  final VoidCallback onConfirm;

  const _HarbourDialog({
    required this.title,
    required this.controller,
    required this.onConfirm,
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: Text(title,
          style: GoogleFonts.inter(fontWeight: FontWeight.bold, fontSize: 16)),
      content: TextField(
        controller: controller,
        autofocus: true,
        decoration: InputDecoration(
          labelText: 'Harbour Name',
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
          prefixIcon: const Icon(Icons.anchor_rounded),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(false),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: onConfirm,
          style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary),
          child: Text('Save',
              style: GoogleFonts.inter(
                  color: Colors.white, fontWeight: FontWeight.w600)),
        ),
      ],
    );
  }
}
