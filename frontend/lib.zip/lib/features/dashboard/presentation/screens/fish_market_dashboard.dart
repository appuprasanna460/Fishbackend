// lib/features/dashboard/presentation/screens/fish_market_dashboard.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/theme/app_sizes.dart';

import '../../../../core/widgets/app_metric_card.dart';
import '../../../../core/widgets/app_loading_overlay.dart';
import '../../../../core/widgets/app_status_badge.dart';
import '../../../auth/presentation/providers/auth_provider.dart';
import '../../../billing/presentation/providers/billing_provider.dart';
import '../../../boats/presentation/providers/boat_provider.dart';
import '../../../fish/presentation/providers/fish_provider.dart';
// ✅ NEW: Import Invoice Template Provider
import '../../../invoice_template/presentation/providers/invoice_template_provider.dart';
// ✅ NEW: Import Invoice Template Entity
import '../../../invoice_template/domain/entities/invoice_template_entity.dart';
import 'notification_list_screen.dart';

class FishMarketDashboard extends ConsumerStatefulWidget {
  const FishMarketDashboard({super.key});

  @override
  ConsumerState<FishMarketDashboard> createState() =>
      _FishMarketDashboardState();
}

class _FishMarketDashboardState extends ConsumerState<FishMarketDashboard> {
  DateTime? _startDate;
  DateTime? _endDate;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(billingProvider.notifier).load();
      ref.read(boatProvider.notifier).load();
      ref.read(fishProvider.notifier).load();
      // ✅ NEW: Load invoice template
      ref.read(invoiceTemplateProvider.notifier).loadActiveTemplate();
    });
  }

  Future<void> _pickDateRange() async {
    final now = DateTime.now();
    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(now.year - 1),
      lastDate: now,
      initialDateRange: DateTimeRange(
        start: now.subtract(const Duration(days: 30)),
        end: now,
      ),
    );
    if (picked != null) {
      setState(() {
        _startDate = picked.start;
        _endDate = picked.end;
      });
    }
  }

  // ✅ NEW: Navigate to Invoice Template Management
  void _navigateToInvoiceTemplate() {
    context.push('/admin/invoice-templates');
  }

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authProvider);
    final billingState = ref.watch(billingProvider);
    final boatState = ref.watch(boatProvider);
    final templateState = ref.watch(invoiceTemplateProvider);
    final user = authState.user;

    final bills = billingState.bills;
    final today = DateTime.now();

    final todayRevenue = bills
        .where((b) {
          final d = b.billDate;
          return d.year == today.year &&
              d.month == today.month &&
              d.day == today.day;
        })
        .fold(0.0, (s, b) => s + b.totalAmount);

    final weekStart = today.subtract(Duration(days: today.weekday - 1));
    final weekRevenue = bills
        .where((b) {
          final d = b.billDate;
          return d.isAfter(weekStart.subtract(const Duration(days: 1))) &&
              !d.isAfter(today);
        })
        .fold(0.0, (s, b) => s + b.totalAmount);

    final monthStart = DateTime(today.year, today.month, 1);
    final monthRevenue = bills
        .where((b) {
          final d = b.billDate;
          return d.isAfter(monthStart.subtract(const Duration(days: 1))) &&
              !d.isAfter(today);
        })
        .fold(0.0, (s, b) => s + b.totalAmount);

    final fishRevenue = <String, double>{};
    final boatRevenue = <String, double>{};
    final locationRevenue = <String, double>{};
    for (final b in bills) {
      fishRevenue[b.boatName] = (fishRevenue[b.boatName] ?? 0) + b.totalAmount;
      boatRevenue[b.boatName] = (boatRevenue[b.boatName] ?? 0) + b.totalAmount;
      locationRevenue[b.agentName] =
          (locationRevenue[b.agentName] ?? 0) + b.totalAmount;
    }

    final topFish = fishRevenue.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    final topBoat = boatRevenue.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    final topLocation = locationRevenue.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    String dateRangeText() {
      if (_startDate != null && _endDate != null) {
        final fmt = DateFormat('dd MMM');
        return '${fmt.format(_startDate!)} - ${fmt.format(_endDate!)}';
      }
      return 'All Time';
    }

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [AppColors.primary, AppColors.primaryLight],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Market Dashboard',
              style: AppTextStyles.h4.copyWith(color: Colors.white),
            ),
            Text(
              '${bills.length} total bills',
              style: AppTextStyles.caption.copyWith(color: Colors.white70),
            ),
          ],
        ),
        actions: [
          // ✅ NEW: Harbour Management Button
          IconButton(
            icon: const Icon(Icons.anchor_rounded, color: Colors.white),
            tooltip: 'Harbours',
            onPressed: () => context.push('/admin/harbours'),
          ),
          // ✅ NEW: Pending Registrations Notification Bell
          Consumer(
            builder: (context, ref, child) {
              final notifState = ref.watch(notificationListProvider);
              final count = notifState.items.where((i) => !i.isActioned).length;
              return Stack(
                alignment: Alignment.center,
                children: [
                  IconButton(
                    icon: const Icon(Icons.notifications_outlined, color: Colors.white),
                    tooltip: 'Pending Approvals',
                    onPressed: () => context.push('/admin/notifications'),
                  ),
                  if (count > 0)
                    Positioned(
                      right: 4,
                      top: 4,
                      child: Container(
                        padding: const EdgeInsets.all(2),
                        decoration: const BoxDecoration(
                          color: Colors.red,
                          shape: BoxShape.circle,
                        ),
                        constraints: const BoxConstraints(
                          minWidth: 15,
                          minHeight: 15,
                        ),
                        child: Text(
                          '$count',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 8,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
          // ✅ NEW: Invoice Template Button
          IconButton(
            icon: const Icon(Icons.description_outlined, color: Colors.white),
            tooltip: 'Invoice Templates',
            onPressed: _navigateToInvoiceTemplate,
          ),
          TextButton.icon(
            onPressed: _pickDateRange,
            icon: const Icon(Icons.date_range, color: Colors.white, size: 18),
            label: Text(
              dateRangeText(),
              style: const TextStyle(color: Colors.white, fontSize: 12),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.person_outline, color: Colors.white),
            onPressed: () => context.push('/admin/profile'),
          ),
        ],
      ),

      body: AppLoadingOverlay(
        isLoading: billingState.isLoading || boatState.isLoading,
        child: RefreshIndicator(
          color: AppColors.primary,
          onRefresh: () async {
            await ref.read(billingProvider.notifier).load();
            await ref.read(boatProvider.notifier).load();
            await ref.read(fishProvider.notifier).load();
            // ✅ NEW: Refresh template
            await ref
                .read(invoiceTemplateProvider.notifier)
                .loadActiveTemplate();
            ref.invalidate(notificationListProvider);
          },
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.all(AppSizes.p16),
            children: [
              // ✅ NEW: Active Template Info Card (Shows current active template)
              if (templateState.template != null)
                _buildActiveTemplateCard(templateState.template!),
              const SizedBox(height: AppSizes.p16),

              Row(
                children: [
                  Expanded(
                    child: _RevenueCard(
                      title: "Today's Revenue",
                      value: '₹${todayRevenue.toStringAsFixed(0)}',
                      icon: Icons.today,
                      color: AppColors.success,
                    ),
                  ),
                  const SizedBox(width: AppSizes.p12),
                  Expanded(
                    child: _RevenueCard(
                      title: 'Weekly Revenue',
                      value: '₹${weekRevenue.toStringAsFixed(0)}',
                      icon: Icons.calendar_view_week,
                      color: AppColors.info,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: AppSizes.p12),
              _RevenueCard(
                title: 'Monthly Revenue',
                value: '₹${monthRevenue.toStringAsFixed(0)}',
                icon: Icons.calendar_month,
                color: AppColors.primary,
                fullWidth: true,
              ),
              const SizedBox(height: AppSizes.p20),

              Row(
                children: [
                  Expanded(
                    child: _TopCard(
                      title: 'Top Fish',
                      entries: topFish.take(3).toList(),
                      valueLabel: (e) => '₹${e.value.toStringAsFixed(0)}',
                      labelFn: (e) => e.key,
                      color: AppColors.accent,
                    ),
                  ),
                  const SizedBox(width: AppSizes.p12),
                  Expanded(
                    child: _TopCard(
                      title: 'Top Boat',
                      entries: topBoat.take(3).toList(),
                      valueLabel: (e) => '₹${e.value.toStringAsFixed(0)}',
                      labelFn: (e) => e.key,
                      color: AppColors.secondary,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: AppSizes.p12),
              _TopCard(
                title: 'Top Location / Agent',
                entries: topLocation.take(3).toList(),
                valueLabel: (e) => '₹${e.value.toStringAsFixed(0)}',
                labelFn: (e) => e.key,
                color: AppColors.primary,
                fullWidth: true,
              ),
              const SizedBox(height: AppSizes.p20),

              Text(
                'Recent Bills',
                style: AppTextStyles.titleMedium.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: AppSizes.p12),
              bills.isEmpty
                  ? Container(
                      padding: const EdgeInsets.all(AppSizes.p20),
                      decoration: BoxDecoration(
                        color: AppColors.surfaceVariant,
                        borderRadius: BorderRadius.circular(AppSizes.radius12),
                        border: Border.all(color: AppColors.border),
                      ),
                      child: const Center(
                        child: Text(
                          'No bills yet',
                          style: TextStyle(color: AppColors.textHint),
                        ),
                      ),
                    )
                  : ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: bills.take(8).length,
                      itemBuilder: (_, i) {
                        final b = bills[i];
                        return Container(
                          margin: const EdgeInsets.only(bottom: AppSizes.p8),
                          padding: const EdgeInsets.symmetric(
                            horizontal: AppSizes.p16,
                            vertical: AppSizes.p12,
                          ),
                          decoration: BoxDecoration(
                            color: AppColors.surface,
                            borderRadius: BorderRadius.circular(
                              AppSizes.radius12,
                            ),
                            border: Border.all(color: AppColors.border),
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 40,
                                height: 40,
                                decoration: BoxDecoration(
                                  color: AppColors.primarySurface,
                                  borderRadius: BorderRadius.circular(
                                    AppSizes.radius8,
                                  ),
                                ),
                                child: Icon(
                                  Icons.receipt,
                                  color: AppColors.primary,
                                  size: 20,
                                ),
                              ),
                              const SizedBox(width: AppSizes.p12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      b.billNumber,
                                      style: AppTextStyles.labelLarge,
                                    ),
                                    Text(
                                      '${b.boatName} • ${b.agentName}',
                                      style: AppTextStyles.bodySmall,
                                    ),
                                  ],
                                ),
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text(
                                    '₹${b.totalAmount.toStringAsFixed(0)}',
                                    style: AppTextStyles.labelLarge.copyWith(
                                      color: AppColors.success,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  AppStatusBadge(label: b.status),
                                ],
                              ),
                            ],
                          ),
                        );
                      },
                    ),
              const SizedBox(height: AppSizes.p32),
            ],
          ),
        ),
      ),
    );
  }

  // ─── NEW: Active Template Card ─────────────────────────────────────────────

  Widget _buildActiveTemplateCard(InvoiceTemplateEntity template) {
    return Container(
      padding: const EdgeInsets.all(AppSizes.p16),
      decoration: BoxDecoration(
        color: AppColors.primary.withOpacity(0.08),
        borderRadius: BorderRadius.circular(AppSizes.radius12),
        border: Border.all(color: AppColors.primary.withOpacity(0.2)),
      ),
      child: InkWell(
        onTap: _navigateToInvoiceTemplate,
        borderRadius: BorderRadius.circular(AppSizes.radius12),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: AppColors.primary.withOpacity(0.15),
                borderRadius: BorderRadius.circular(AppSizes.radius8),
              ),
              child: const Icon(
                Icons.description,
                color: AppColors.primary,
                size: 20,
              ),
            ),
            const SizedBox(width: AppSizes.p12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Active Invoice Template',
                    style: AppTextStyles.labelLarge.copyWith(
                      color: AppColors.primary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    template.title,
                    style: AppTextStyles.bodyMedium.copyWith(
                      color: AppColors.textSecondary,
                    ),
                  ),
                  Text(
                    template.subtitle,
                    style: AppTextStyles.bodySmall.copyWith(
                      color: AppColors.textHint,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: AppColors.primary,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Text(
                'Edit',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const SizedBox(width: 4),
            const Icon(Icons.chevron_right, color: AppColors.primary, size: 20),
          ],
        ),
      ),
    );
  }
}

// ─── Reusable Widgets ────────────────────────────────────────────────────────

class _RevenueCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  final Color color;
  final bool fullWidth;

  const _RevenueCard({
    required this.title,
    required this.value,
    required this.icon,
    required this.color,
    this.fullWidth = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(AppSizes.p16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color, color.withOpacity(0.8)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(AppSizes.radius16),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(AppSizes.radius12),
            ),
            child: Icon(icon, color: Colors.white, size: 24),
          ),
          const SizedBox(width: AppSizes.p16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: AppTextStyles.caption.copyWith(color: Colors.white70),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: AppTextStyles.h3.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _TopCard extends StatelessWidget {
  final String title;
  final List<MapEntry<String, double>> entries;
  final String Function(MapEntry<String, double>) valueLabel;
  final String Function(MapEntry<String, double>) labelFn;
  final Color color;
  final bool fullWidth;

  const _TopCard({
    required this.title,
    required this.entries,
    required this.valueLabel,
    required this.labelFn,
    required this.color,
    this.fullWidth = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(AppSizes.p16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(AppSizes.radius16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.emoji_events, size: 18, color: color),
              const SizedBox(width: AppSizes.p8),
              Text(
                title,
                style: AppTextStyles.labelLarge.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSizes.p12),
          if (entries.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8.0),
              child: Text(
                'No data available',
                style: AppTextStyles.bodySmall.copyWith(
                  color: AppColors.textHint,
                ),
              ),
            )
          else
            ...entries.map((e) {
              final rank = entries.indexOf(e) + 1;
              return Padding(
                padding: const EdgeInsets.only(bottom: AppSizes.p10),
                child: Row(
                  children: [
                    Container(
                      width: 24,
                      height: 24,
                      decoration: BoxDecoration(
                        color: color.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Center(
                        child: Text(
                          '$rank',
                          style: AppTextStyles.caption.copyWith(
                            color: color,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: AppSizes.p10),
                    Expanded(
                      child: Text(
                        labelFn(e),
                        style: AppTextStyles.bodyMedium,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Text(
                      valueLabel(e),
                      style: AppTextStyles.labelLarge.copyWith(
                        color: color,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              );
            }).toList(),
        ],
      ),
    );
  }
}
