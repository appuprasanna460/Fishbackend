import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF003087),

      body: SafeArea(
        child: Column(
          children: [

            // ─────────────────────────────────────
            // IMAGE + BUTTONS OVERLAID ON TOP
            // ─────────────────────────────────────
            Expanded(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  Image.asset(
                    'assets/image.png',
                    width: double.infinity,
                    fit: BoxFit.cover,
                  ),

                  // dark gradient so button text/border stays readable
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.transparent,
                          const Color(0xFF003087).withOpacity(0.75),
                        ],
                        stops: const [0.4, 0.9],
                      ),
                    ),
                  ),

                  Positioned(
                    left: 24,
                    right: 24,
                    bottom: 99,
                    child: Column(
                      children: [
                        _WelcomeButton(
                          label: 'Sign In',
                          isPrimary: true,
                          showArrow: true,
                          onTap: () => context.go('/login'),
                        ),
                        const SizedBox(height: 8),
                        _WelcomeButton(
                          label: 'Create Account',
                          isPrimary: false,
                          showArrow: false,
                          onTap: () => context.push('/select-harbour'),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

          ],
        ),
      ),
    );
  }
}


// ─────────────────────────────────────────────
// BUTTON — minimized size
// ─────────────────────────────────────────────

class _WelcomeButton extends StatelessWidget {
  final String label;
  final bool isPrimary;
  final bool showArrow;
  final VoidCallback onTap;

  const _WelcomeButton({
    required this.label,
    required this.isPrimary,
    required this.showArrow,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,

      child: Container(
        width: double.infinity,
        height: 40,

        decoration: BoxDecoration(
          // Sign In: solid #003087. Create Account: transparent with
          // white border/text — palette is #003087 + white only.
          color: isPrimary ? const Color(0xFF003087) : Colors.transparent,

          borderRadius: BorderRadius.circular(20),

          border: isPrimary
              ? null
              : Border.all(
                  color: Colors.white,
                  width: 1.0,
                ),

          boxShadow: isPrimary
              ? [
                  BoxShadow(
                    color: const Color(0xFF003087).withOpacity(0.35),
                    blurRadius: 6,
                    offset: const Offset(0, 3),
                  ),
                ]
              : null,
        ),

        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [

            Text(
              label,
              style: GoogleFonts.inter(
                color: Colors.white,
                fontSize: 13,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.2,
              ),
            ),

            if (showArrow) ...[
              const SizedBox(width: 6),

              const Icon(
                Icons.arrow_forward,
                color: Colors.white,
                size: 15,
              ),
            ],
          ],
        ),
      ),
    );
  }
}