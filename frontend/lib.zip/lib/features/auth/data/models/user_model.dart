import '../../domain/entities/user_entity.dart';

class UserModel extends UserEntity {
  const UserModel({
    required super.id,
    required super.name,
    required super.email,
    required super.phone,
    required super.role,
    required super.isActive,
    super.agentId,
    super.locationId,
    super.subLocationId,
    super.createdAt,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['_id'] as String? ?? json['id'] as String? ?? '',
      name: json['name'] as String? ?? '',
      email: json['email'] as String? ?? '',
      phone: json['phone'] as String? ?? '',
      role: json['role'] as String? ?? 'STAFF',
      isActive: json['isActive'] as bool? ?? true,
      agentId: json['agentId'] as String?,
      locationId: json['locationId'] is String
          ? json['locationId'] as String
          : (json['locationId'] as Map<String, dynamic>?)?['_id'] as String?,
      subLocationId: json['subLocationId'] is String
          ? json['subLocationId'] as String
          : (json['subLocationId'] as Map<String, dynamic>?)?['_id'] as String?,
      createdAt: json['createdAt'] != null
          ? DateTime.tryParse(json['createdAt'] as String)
          : null,
    );
  }

  Map<String, dynamic> toJson() => {
        'name': name,
        'email': email,
        'phone': phone,
        'role': role,
        'isActive': isActive,
        if (agentId != null) 'agentId': agentId,
        if (locationId != null) 'locationId': locationId,
        if (subLocationId != null) 'subLocationId': subLocationId,
      };
}
