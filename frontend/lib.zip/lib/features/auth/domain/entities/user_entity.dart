class UserEntity {
  final String id;
  final String name;
  final String email;
  final String phone;
  final String role;
  final bool isActive;
  final String? agentId;
  final String? locationId;
  final String? subLocationId;
  final DateTime? createdAt;

  const UserEntity({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    required this.role,
    required this.isActive,
    this.agentId,
    this.locationId,
    this.subLocationId,
    this.createdAt,
  });

  String get displayRole => role
      .replaceAll('_', ' ')
      .split(' ')
      .map((w) => w[0].toUpperCase() + w.substring(1).toLowerCase())
      .join(' ');

  bool get isSuperAdmin => role == 'SUPER_ADMIN';
  bool get isAgent => role == 'COMMISSION_AGENT';
  bool get isOwner => role == 'BOAT_OWNER';
  bool get isStaff => role == 'STAFF';
}
