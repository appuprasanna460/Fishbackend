import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/theme/app_sizes.dart';
import '../../../../core/widgets/app_empty_state.dart';
import '../../../../core/widgets/app_loading_overlay.dart';
import '../../../../core/widgets/app_confirm_dialog.dart';
import '../providers/user_provider.dart';
import '../../../auth/presentation/providers/auth_provider.dart';
import '../../../locations/presentation/providers/location_provider.dart';
import '../../data/models/user_model.dart';

class UserListScreen extends ConsumerStatefulWidget {
  const UserListScreen({super.key});

  @override
  ConsumerState<UserListScreen> createState() => _UserListScreenState();
}

class _UserListScreenState extends ConsumerState<UserListScreen> {
  final _searchController = TextEditingController();
  String _selectedRole = 'ALL';

  final List<String> _roles = [
    'ALL',
    'SUPER_ADMIN',
    'COMMISSION_AGENT',
    'STAFF',
    'FISH_BUYER',
    'BOAT_OWNER',
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(userProvider.notifier).load();
      ref.read(locationProvider.notifier).load();
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _onSearchChanged(String val) {
    ref
        .read(userProvider.notifier)
        .load(
          role: _selectedRole,
          search: val.isEmpty ? null : val, // Don't send empty search
        );
  }

  void _onRoleChanged(String role) {
    setState(() => _selectedRole = role);
    final searchText = _searchController.text;
    ref
        .read(userProvider.notifier)
        .load(
          role: role == 'ALL' ? null : role,
          search: searchText.isEmpty ? null : searchText,
        );
  }

  // void _goBack() {
  //   // Try multiple navigation methods
  //   try {
  //     // Method 1: Use go_router's pop
  //     if (context.mounted) {
  //       final router = GoRouter.of(context);
  //       if (router.canPop()) {
  //         router.pop();
  //       } else {
  //         // If can't pop, navigate to dashboard
  //         context.go('/admin/dashboard');
  //       }
  //     }
  //   } catch (e) {
  //     // Method 2: Use Navigator
  //     if (Navigator.canPop(context)) {
  //       Navigator.pop(context);
  //     } else {
  //       // Method 3: Fallback to go
  //       context.go('/admin/dashboard');
  //     }
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(userProvider);
    final authState = ref.watch(authProvider);
    final isSuperAdmin = authState.user?.role == 'SUPER_ADMIN';
    final locationState = ref.watch(locationProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('User Management'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => ref
                .read(userProvider.notifier)
                .load(
                  role: _selectedRole == 'ALL' ? null : _selectedRole,
                  search: _searchController.text.isEmpty
                      ? null
                      : _searchController.text,
                ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => context.push('/admin/users/new'),
        icon: const Icon(Icons.add_moderator),
        label: const Text('Add User'),
        backgroundColor: AppColors.primary,
        foregroundColor: AppColors.surface,
      ),
      body: AppLoadingOverlay(
        isLoading: state.isLoading,
        child: Column(
          children: [
            // Search Bar
            Padding(
              padding: const EdgeInsets.all(AppSizes.p16),
              child: TextField(
                controller: _searchController,
                onChanged: _onSearchChanged,
                decoration: InputDecoration(
                  hintText: 'Search by name or email...',
                  prefixIcon: const Icon(Icons.search, size: AppSizes.iconMd),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(AppSizes.radius12),
                  ),
                  contentPadding: const EdgeInsets.symmetric(
                    vertical: 0,
                    horizontal: AppSizes.p16,
                  ),
                ),
              ),
            ),
            // Role Filter Chips
            Container(
              height: 48,
              padding: const EdgeInsets.symmetric(horizontal: AppSizes.p16),
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: _roles.length,
                itemBuilder: (_, idx) {
                  final role = _roles[idx];
                  final isSelected = _selectedRole == role;
                  return Padding(
                    padding: const EdgeInsets.only(right: AppSizes.p8),
                    child: FilterChip(
                      selected: isSelected,
                      label: Text(
                        role.split('_').join(' ').toLowerCase().toUpperCase(),
                      ),
                      onSelected: (_) => _onRoleChanged(role),
                      selectedColor: AppColors.primarySurface,
                      checkmarkColor: AppColors.primary,
                      labelStyle: AppTextStyles.bodySmall.copyWith(
                        color: isSelected
                            ? AppColors.primary
                            : AppColors.textSecondary,
                        fontWeight: isSelected
                            ? FontWeight.w600
                            : FontWeight.normal,
                      ),
                    ),
                  );
                },
              ),
            ),
            const Divider(height: 1),
            if (state.error != null)
              Container(
                width: double.infinity,
                margin: const EdgeInsets.all(AppSizes.p16),
                padding: const EdgeInsets.all(AppSizes.p12),
                decoration: BoxDecoration(
                  color: AppColors.errorLight,
                  borderRadius: BorderRadius.circular(AppSizes.radius8),
                ),
                child: Row(
                  children: [
                    Icon(Icons.error_outline, color: AppColors.error, size: 20),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        state.error!,
                        style: AppTextStyles.bodySmall.copyWith(
                          color: AppColors.error,
                        ),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.refresh, size: 18),
                      onPressed: () => ref
                          .read(userProvider.notifier)
                          .load(
                            role: _selectedRole == 'ALL' ? null : _selectedRole,
                            search: _searchController.text.isEmpty
                                ? null
                                : _searchController.text,
                          ),
                    ),
                  ],
                ),
              ),
            Expanded(
              child: state.users.isEmpty && !state.isLoading
                  ? const AppEmptyState(
                      title: 'No Users Found',
                      subtitle:
                          'Add new staff, buyers, or agents to get started.',
                      icon: Icons.people_outline,
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.all(AppSizes.p16),
                      itemCount: state.users.length,
itemBuilder: (_, idx) {
                          final user = state.users[idx];

                          // Resolve location name
                          String locationName = 'None';
                          if (user.locationId != null) {
                            for (final l in locationState.locations) {
                              if (l.id == user.locationId) {
                                locationName = l.name;
                                break;
                              }
                            }
                          }

                          if (user.role == 'BOAT_OWNER' && _selectedRole == 'BOAT_OWNER') {
                            String agentName = user.agentId != null && user.agentId!.isNotEmpty
                                ? state.users.firstWhere(
                                    (a) => a.id == user.agentId,
                                    orElse: () => const UserModel(
                                      id: '',
                                      name: '',
                                      email: '',
                                      phone: '',
                                      role: 'STAFF',
                                      isActive: true,
                                    ),
                                  ).name
                                : 'N/A';
                            if (agentName.isEmpty) agentName = 'N/A';
                            return Card(
                              margin: const EdgeInsets.only(bottom: AppSizes.p12),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(AppSizes.radius12),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(AppSizes.p16),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          user.name,
                                          style: AppTextStyles.titleMedium.copyWith(
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: AppSizes.p6,
                                            vertical: AppSizes.p4,
                                          ),
                                          decoration: BoxDecoration(
                                            color: user.isActive
                                                ? AppColors.successLight
                                                : AppColors.errorLight,
                                            borderRadius: BorderRadius.circular(AppSizes.radius4),
                                          ),
                                          child: Text(
                                            user.isActive ? 'ACTIVE' : 'INACTIVE',
                                            style: AppTextStyles.labelSmall.copyWith(
                                              color: user.isActive ? AppColors.success : AppColors.error,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: AppSizes.p8),
                                    Row(
                                      children: [
                                        const Icon(Icons.phone_outlined, size: 16, color: AppColors.primary),
                                        const SizedBox(width: 8),
                                        Text(
                                          user.phone.isNotEmpty ? user.phone : 'No Phone',
                                          style: AppTextStyles.bodyMedium,
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 4),
                                    Row(
                                      children: [
                                        const Icon(Icons.location_on_outlined, size: 16, color: AppColors.primary),
                                        const SizedBox(width: 8),
                                        Text(
                                          'Location : $locationName',
                                          style: AppTextStyles.bodyMedium,
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 4),
                                    Row(
                                      children: [
                                        const Icon(Icons.directions_boat_outlined, size: 16, color: AppColors.primary),
                                        const SizedBox(width: 8),
                                        Text(
                                          'Total Boats : ${user.totalBoats ?? 0}',
                                          style: AppTextStyles.bodyMedium.copyWith(
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 4),
                                    Row(
                                      children: [
                                        const Icon(Icons.person_outline, size: 16, color: AppColors.primary),
                                        const SizedBox(width: 8),
                                        Text(
                                          'Agent : $agentName',
                                          style: AppTextStyles.bodyMedium,
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: AppSizes.p12),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        Expanded(
                                          child: OutlinedButton(
                                            onPressed: () => context.push('/admin/users/${user.id}'),
                                            style: OutlinedButton.styleFrom(
                                              padding: const EdgeInsets.symmetric(horizontal: AppSizes.p16, vertical: AppSizes.p8),
                                              side: const BorderSide(color: AppColors.primary),
                                              shape: RoundedRectangleBorder(
                                                borderRadius: BorderRadius.circular(AppSizes.radius8),
                                              ),
                                            ),
                                            child: const Text('View'),
                                          ),
                                        ),
                                        const SizedBox(width: 12),
                                        Expanded(
                                          child: ElevatedButton(
                                            onPressed: () => context.push('/admin/users/${user.id}/edit'),
                                            style: ElevatedButton.styleFrom(
                                              backgroundColor: AppColors.primary,
                                              foregroundColor: Colors.white,
                                              padding: const EdgeInsets.symmetric(horizontal: AppSizes.p16, vertical: AppSizes.p8),
                                              shape: RoundedRectangleBorder(
                                                borderRadius: BorderRadius.circular(AppSizes.radius8),
                                              ),
                                            ),
                                            child: const Text('Edit'),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            );
                          }

                          return Card(
                            margin: const EdgeInsets.only(bottom: AppSizes.p12),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(AppSizes.radius12),
                            ),
                            child: ListTile(
                              contentPadding: const EdgeInsets.all(AppSizes.p16),
                              leading: CircleAvatar(
                                backgroundColor: AppColors.primary,
                                child: Text(
                                  user.name.isNotEmpty
                                      ? user.name[0].toUpperCase()
                                      : 'U',
                                  style: AppTextStyles.titleMedium.copyWith(
                                    color: AppColors.surface,
                                  ),
                                ),
                              ),
                              title: Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      user.name,
                                      style: AppTextStyles.titleMedium.copyWith(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: AppSizes.p6,
                                      vertical: AppSizes.p4,
                                    ),
                                    decoration: BoxDecoration(
                                      color: user.isActive
                                          ? AppColors.successLight
                                          : AppColors.errorLight,
                                      borderRadius: BorderRadius.circular(AppSizes.radius4),
                                    ),
                                    child: Text(
                                      user.isActive ? 'ACTIVE' : 'INACTIVE',
                                      style: AppTextStyles.labelSmall.copyWith(
                                        color: user.isActive
                                            ? AppColors.success
                                            : AppColors.error,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              subtitle: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const SizedBox(height: 4),
                                  Text(
                                    user.email,
                                    style: AppTextStyles.bodyMedium,
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    'Role: ${user.displayRole}',
                                    style: AppTextStyles.bodySmall.copyWith(
                                      color: AppColors.textSecondary,
                                    ),
                                  ),
                                ],
                              ),
                              onTap: () =>
                                  context.push('/admin/users/${user.id}'),
                              trailing: isSuperAdmin && user.role != 'SUPER_ADMIN'
                                  ? PopupMenuButton<String>(
                                      itemBuilder: (_) => [
                                        const PopupMenuItem(
                                          value: 'edit',
                                          child: Row(
                                            children: [
                                              Icon(
                                                Icons.edit_outlined,
                                                size: 18,
                                                color: AppColors.primary,
                                              ),
                                              SizedBox(width: 8),
                                              Text('Edit'),
                                            ],
                                          ),
                                        ),
                                        const PopupMenuItem(
                                          value: 'delete',
                                          child: Row(
                                            children: [
                                              Icon(
                                                Icons.delete_outline,
                                                size: 18,
                                                color: AppColors.error,
                                              ),
                                              SizedBox(width: 8),
                                              Text('Delete'),
                                            ],
                                          ),
                                        ),
                                      ],
                                      onSelected: (val) async {
                                        if (val == 'edit') {
                                          context.push(
                                            '/admin/users/${user.id}/edit',
                                          );
                                        } else if (val == 'delete') {
                                          final confirm = await AppConfirmDialog.show(
                                            context: context,
                                            title: 'Delete User',
                                            message:
                                                'Are you sure you want to delete ${user.name}? This action cannot be undone.',
                                            confirmLabel: 'Delete',
                                            isDangerous: true,
                                            icon: Icons.delete_outline,
                                          );
                                          if (confirm != true) return;
                                          final ok = await ref
                                              .read(userProvider.notifier)
                                              .deleteUser(user.id);
                                          if (ok && mounted) {
                                            ScaffoldMessenger.of(
                                              context,
                                            ).showSnackBar(
                                              SnackBar(
                                                content: Text(
                                                  '${user.name} deleted',
                                                ),
                                              ),
                                            );
                                          }
                                        }
                                      },
                                    )
                                  : null,
                            ),
                          );
                        },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
