import '../../domain/entities/user_entity.dart';

class UserModel extends UserEntity {
  const UserModel({
    required super.id,
    required super.name,
    required super.email,
    required super.phone,
    required super.role,
    required super.isActive,
    super.agentId,
    super.locationId,
    super.subLocationId,
    super.createdAt,
    super.totalBoats,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    dynamic totalBoatsValue = json['totalBoats'];
    int? totalBoats;
    if (totalBoatsValue != null) {
      if (totalBoatsValue is int) {
        totalBoats = totalBoatsValue;
      } else if (totalBoatsValue is double) {
        totalBoats = totalBoatsValue.toInt();
      } else if (totalBoatsValue is String) {
        totalBoats = int.tryParse(totalBoatsValue);
      }
    }

    String? parseRefId(String fieldName) {
      final value = json[fieldName];
      if (value == null) return null;
      if (value is String) return value;
      if (value is Map) return value['_id'] as String? ?? value['id'] as String?;
      return null;
    }

    return UserModel(
      id: json['_id'] as String? ?? json['id'] as String? ?? '',
      name: json['name'] as String? ?? '',
      email: json['email'] as String? ?? '',
      phone: json['phone'] as String? ?? '',
      role: json['role'] as String? ?? 'STAFF',
      isActive: json['isActive'] as bool? ?? true,
      agentId: parseRefId('agentId'),
      locationId: parseRefId('locationId'),
      subLocationId: parseRefId('subLocationId'),
      createdAt: json['createdAt'] != null
          ? DateTime.tryParse(json['createdAt'] as String)
          : null,
      totalBoats: totalBoats,
    );
  }

  Map<String, dynamic> toJson() => {
        'name': name,
        'email': email,
        'phone': phone,
        'role': role,
        'isActive': isActive,
        if (agentId != null) 'agentId': agentId,
        if (locationId != null) 'locationId': locationId,
        if (subLocationId != null) 'subLocationId': subLocationId,
        if (totalBoats != null) 'totalBoats': totalBoats,
      };
}
