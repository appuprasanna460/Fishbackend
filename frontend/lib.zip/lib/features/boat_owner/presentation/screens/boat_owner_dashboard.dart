// lib/features/boat_owner/presentation/screens/boat_owner_dashboard.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/theme/app_sizes.dart';
import '../../../../core/widgets/app_loading_overlay.dart';
import '../../../../core/widgets/app_metric_card.dart';
import '../../../auth/presentation/providers/auth_provider.dart';
import '../../data/boat_owner_api_service.dart';

// ─────────────────────────────────────────────────────────────────────────────
// Local models parsed from the dashboard API response
// ─────────────────────────────────────────────────────────────────────────────
class _DashboardData {
  final double todayRevenue;
  final double weeklyRevenue;
  final double monthlyRevenue;
  final int totalBoats;
  final int todayBillCount;
  final double totalWeightSold;
  final List<Map<String, dynamic>> revenueChart;
  final List<Map<String, dynamic>> boatPerformance;
  final List<Map<String, dynamic>> topFish;

  const _DashboardData({
    this.todayRevenue = 0,
    this.weeklyRevenue = 0,
    this.monthlyRevenue = 0,
    this.totalBoats = 0,
    this.todayBillCount = 0,
    this.totalWeightSold = 0,
    this.revenueChart = const [],
    this.boatPerformance = const [],
    this.topFish = const [],
  });

  factory _DashboardData.fromJson(Map<String, dynamic> json) {
    final s = json['summary'] as Map<String, dynamic>? ?? {};
    return _DashboardData(
      todayRevenue: (s['todayRevenue'] ?? 0).toDouble(),
      weeklyRevenue: (s['weeklyRevenue'] ?? 0).toDouble(),
      monthlyRevenue: (s['monthlyRevenue'] ?? 0).toDouble(),
      totalBoats: (s['totalBoats'] ?? 0) as int,
      todayBillCount: (s['todayBillCount'] ?? 0) as int,
      totalWeightSold: (s['totalWeightSold'] ?? 0).toDouble(),
      revenueChart: List<Map<String, dynamic>>.from(json['revenueChart'] ?? []),
      boatPerformance: List<Map<String, dynamic>>.from(
        json['boatPerformance'] ?? [],
      ),
      topFish: List<Map<String, dynamic>>.from(json['topFish'] ?? []),
    );
  }
}

class _DashboardState {
  final _DashboardData? data;
  final bool isLoading;
  final String? error;
  const _DashboardState({this.data, this.isLoading = false, this.error});
  _DashboardState copyWith({
    _DashboardData? data,
    bool? isLoading,
    String? error,
  }) => _DashboardState(
    data: data ?? this.data,
    isLoading: isLoading ?? this.isLoading,
    error: error,
  );
}

class _DashboardNotifier extends StateNotifier<_DashboardState> {
  final BoatOwnerApiService _api;
  _DashboardNotifier(this._api) : super(const _DashboardState()) {
    load();
  }

  Future<void> load() async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      final raw = await _api.getDashboard();
      state = state.copyWith(
        data: _DashboardData.fromJson(raw),
        isLoading: false,
      );
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }
}

final _dashboardProvider =
    StateNotifierProvider.autoDispose<_DashboardNotifier, _DashboardState>((
      ref,
    ) {
      return _DashboardNotifier(
        BoatOwnerApiService(ref.watch(dioClientProvider)),
      );
    });

// ─────────────────────────────────────────────────────────────────────────────
// Screen
// ─────────────────────────────────────────────────────────────────────────────
class BoatOwnerDashboard extends ConsumerWidget {
  const BoatOwnerDashboard({super.key});

  // ✅ Navigation methods
  void _navigateToBoats(BuildContext context) {
    context.go('/owner/my-boats'); // ✅ Use go() instead of push()
  }

  void _navigateToBills(BuildContext context) {
    context.push('/owner/bills');
  }

  void _navigateToLedger(BuildContext context) {
    context.push('/owner/ledger');
  }

  void _navigateToLocation(BuildContext context) {
    context.push('/owner/location');
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final dashState = ref.watch(_dashboardProvider);
    final authState = ref.watch(authProvider);
    final user = authState.user;
    final now = DateTime.now();
    final d = dashState.data;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => ref.read(_dashboardProvider.notifier).load(),
          ),
        ],
      ),
      body: AppLoadingOverlay(
        isLoading: dashState.isLoading,
        child: RefreshIndicator(
          onRefresh: () => ref.read(_dashboardProvider.notifier).load(),
          child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.all(AppSizes.p16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ── Error ──────────────────────────────────────────────────
                if (dashState.error != null)
                  Container(
                    width: double.infinity,
                    margin: const EdgeInsets.only(bottom: AppSizes.p12),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: AppColors.errorLight,
                      borderRadius: BorderRadius.circular(AppSizes.radius12),
                    ),
                    child: Text(
                      'Error: ${dashState.error}',
                      style: const TextStyle(color: Colors.red),
                    ),
                  ),

                // ── Welcome ────────────────────────────────────────────────
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Welcome, ${user?.name ?? "Owner"}',
                          style: AppTextStyles.h4,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          DateFormat('dd MMMM yyyy').format(now),
                          style: AppTextStyles.caption.copyWith(
                            color: AppColors.textHint,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: AppSizes.p16),

                // ── Quick Actions ──────────────────────────────────────────
                _buildQuickActions(context),
                const SizedBox(height: AppSizes.p16),

                // ── Summary Cards ──────────────────────────────────────────
                Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  children: [
                    _buildMetricCard(
                      title: "Today's Revenue",
                      value: '₹${(d?.todayRevenue ?? 0).toStringAsFixed(0)}',
                      icon: Icons.currency_rupee,
                      color: AppColors.success,
                    ),
                    _buildMetricCard(
                      title: 'Weekly Revenue',
                      value: '₹${(d?.weeklyRevenue ?? 0).toStringAsFixed(0)}',
                      icon: Icons.trending_up,
                      color: AppColors.primary,
                    ),
                    _buildMetricCard(
                      title: 'Monthly Revenue',
                      value: '₹${(d?.monthlyRevenue ?? 0).toStringAsFixed(0)}',
                      icon: Icons.calendar_month,
                      color: AppColors.info,
                    ),
                    _buildMetricCard(
                      title: 'Total Boats',
                      value: '${d?.totalBoats ?? 0}',
                      icon: Icons.directions_boat,
                      color: AppColors.secondary,
                    ),
                    _buildMetricCard(
                      title: "Today's Bills",
                      value: '${d?.todayBillCount ?? 0}',
                      icon: Icons.receipt_long,
                      color: AppColors.accent,
                    ),
                    _buildMetricCard(
                      title: 'Total Weight Sold',
                      value:
                          '${(d?.totalWeightSold ?? 0).toStringAsFixed(0)} kg',
                      icon: Icons.scale,
                      color: AppColors.warning,
                    ),
                  ],
                ),
                const SizedBox(height: AppSizes.p24),

                // ── Revenue Chart (last 7 days) ─────────────────────────────
                if (d != null && d.revenueChart.isNotEmpty) ...[
                  Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(AppSizes.radius16),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(AppSizes.p16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Revenue — Last 7 Days',
                            style: AppTextStyles.titleMedium.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: AppSizes.p16),
                          SizedBox(
                            height: 220,
                            child: _RevenueBarChart(data: d.revenueChart),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: AppSizes.p24),
                ],

                // ── My Boats (location status) ─────────────────────────────
                if (d != null && d.boatPerformance.isNotEmpty) ...[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'My Boats',
                        style: AppTextStyles.titleMedium.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      TextButton(
                        onPressed: () => _navigateToBoats(context),
                        child: const Text('View All →'),
                      ),
                    ],
                  ),
                  const SizedBox(height: AppSizes.p12),
                  ...d.boatPerformance.take(3).map((boat) {
                    final status = boat['locationStatus'] ?? 'PENDING';
                    final saved = status == 'SAVED';
                    return Card(
                      margin: const EdgeInsets.only(bottom: AppSizes.p8),
                      child: ListTile(
                        leading: const Icon(
                          Icons.directions_boat,
                          color: AppColors.primary,
                        ),
                        title: Text(
                          boat['boatName'] ?? '',
                          style: AppTextStyles.labelLarge,
                        ),
                        subtitle: Text(
                          "Revenue: ₹${(boat['totalRevenue'] ?? 0).toStringAsFixed(0)} | Bills: ${boat['totalBills'] ?? 0}",
                        ),
                        trailing: Chip(
                          label: Text(
                            saved ? 'Saved ✅' : 'Pending ⚠️',
                            style: const TextStyle(fontSize: 12),
                          ),
                          backgroundColor: saved
                              ? AppColors.successLight.withOpacity(0.3)
                              : AppColors.warningLight.withOpacity(0.3),
                        ),
                      ),
                    );
                  }),
                  const SizedBox(height: AppSizes.p24),
                ],

                // ── Boat Performance ──────────────────────────────────────
                if (d != null && d.boatPerformance.isNotEmpty) ...[
                  Text(
                    'Boat Performance',
                    style: AppTextStyles.titleMedium.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: AppSizes.p12),
                  ...d.boatPerformance.take(3).map((boat) {
                    final isActive = boat['isActive'] ?? false;
                    return Card(
                      margin: const EdgeInsets.only(bottom: AppSizes.p8),
                      child: Padding(
                        padding: const EdgeInsets.all(AppSizes.p16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  boat['boatName'] ?? '',
                                  style: AppTextStyles.labelLarge.copyWith(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  isActive ? 'ACTIVE' : 'INACTIVE',
                                  style: TextStyle(
                                    color: isActive
                                        ? AppColors.success
                                        : AppColors.error,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "Revenue: ₹${(boat['totalRevenue'] ?? 0).toStringAsFixed(0)}",
                                  style: AppTextStyles.bodyMedium,
                                ),
                                Text(
                                  "Bills: ${boat['totalBills'] ?? 0}",
                                  style: AppTextStyles.bodyMedium,
                                ),
                              ],
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "Weight: ${(boat['totalWeight'] ?? 0).toStringAsFixed(0)} kg",
                                  style: AppTextStyles.bodyMedium,
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  }),
                  const SizedBox(height: AppSizes.p24),
                ],

                // ── Top Selling Fish ───────────────────────────────────────
                if (d != null && d.topFish.isNotEmpty) ...[
                  Text(
                    'Top Selling Fish',
                    style: AppTextStyles.titleMedium.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: AppSizes.p12),
                  ...d.topFish.take(5).map((fish) {
                    return Card(
                      margin: const EdgeInsets.only(bottom: AppSizes.p8),
                      child: ListTile(
                        leading: const Icon(Icons.water, color: AppColors.info),
                        title: Text(
                          fish['fishName'] ?? '',
                          style: AppTextStyles.labelLarge,
                        ),
                        subtitle: Text(
                          "Weight: ${(fish['totalWeight'] ?? 0).toStringAsFixed(0)} kg",
                        ),
                        trailing: Text(
                          '₹${(fish['totalAmount'] ?? 0).toStringAsFixed(0)}',
                          style: AppTextStyles.labelLarge.copyWith(
                            color: AppColors.success,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    );
                  }),
                  const SizedBox(height: AppSizes.p32),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ✅ Quick Actions Grid
  Widget _buildQuickActions(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          _buildQuickActionCard(
            context,
            icon: Icons.directions_boat,
            label: 'My Boats',
            color: AppColors.primary,
            onTap: () => _navigateToBoats(context),
          ),
          const SizedBox(width: 12),
          _buildQuickActionCard(
            context,
            icon: Icons.receipt_long,
            label: 'Bills',
            color: AppColors.success,
            onTap: () => _navigateToBills(context),
          ),
          const SizedBox(width: 12),
          _buildQuickActionCard(
            context,
            icon: Icons.account_balance_wallet,
            label: 'Ledger',
            color: AppColors.info,
            onTap: () => _navigateToLedger(context),
          ),
          const SizedBox(width: 12),
          _buildQuickActionCard(
            context,
            icon: Icons.location_on,
            label: 'Locations',
            color: AppColors.warning,
            onTap: () => _navigateToLocation(context),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActionCard(
    BuildContext context, {
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppSizes.radius12),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: color.withOpacity(0.08),
            borderRadius: BorderRadius.circular(AppSizes.radius12),
            border: Border.all(color: color.withOpacity(0.2)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: color, size: 28),
              const SizedBox(height: 6),
              Text(
                label,
                style: AppTextStyles.bodySmall.copyWith(
                  color: color,
                  fontWeight: FontWeight.w600,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ✅ Helper method to build individual metric cards
  Widget _buildMetricCard({
    required String title,
    required String value,
    required IconData icon,
    required Color color,
  }) {
    final screenWidth =
        WidgetsBinding.instance.window.physicalSize.width /
        WidgetsBinding.instance.window.devicePixelRatio;
    final cardWidth = (screenWidth - 48) / 2;

    return SizedBox(
      width: cardWidth > 0 ? cardWidth : 160,
      child: AppMetricCard(
        title: title,
        value: value,
        icon: icon,
        color: color,
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Revenue Bar Chart widget
// ─────────────────────────────────────────────────────────────────────────────
class _RevenueBarChart extends StatelessWidget {
  final List<Map<String, dynamic>> data;
  const _RevenueBarChart({required this.data});

  @override
  Widget build(BuildContext context) {
    double maxY = data.fold(
      0.0,
      (m, e) => ((e['revenue'] ?? 0) as num).toDouble() > m
          ? ((e['revenue'] ?? 0) as num).toDouble()
          : m,
    );
    if (maxY == 0) maxY = 10000;

    final groups = <BarChartGroupData>[];
    for (int i = 0; i < data.length; i++) {
      final rev = ((data[i]['revenue'] ?? 0) as num).toDouble();
      groups.add(
        BarChartGroupData(
          x: i,
          barRods: [
            BarChartRodData(
              toY: rev,
              color: AppColors.primary,
              width: 16,
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(4),
              ),
            ),
          ],
        ),
      );
    }

    return BarChart(
      BarChartData(
        alignment: BarChartAlignment.spaceAround,
        maxY: maxY * 1.2,
        barTouchData: BarTouchData(enabled: true),
        titlesData: FlTitlesData(
          show: true,
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 28,
              getTitlesWidget: (value, meta) {
                final idx = value.toInt();
                if (idx < 0 || idx >= data.length) {
                  return const SizedBox.shrink();
                }
                final dateStr = data[idx]['date'] as String? ?? '';
                String label = '';
                try {
                  final d = DateTime.parse(dateStr);
                  label = DateFormat('dd/MM').format(d);
                } catch (_) {}
                return SideTitleWidget(
                  meta: meta,
                  space: 4,
                  child: Text(
                    label,
                    style: const TextStyle(
                      color: Colors.grey,
                      fontSize: 9,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                );
              },
            ),
          ),
          leftTitles: const AxisTitles(
            sideTitles: SideTitles(showTitles: false),
          ),
          topTitles: const AxisTitles(
            sideTitles: SideTitles(showTitles: false),
          ),
          rightTitles: const AxisTitles(
            sideTitles: SideTitles(showTitles: false),
          ),
        ),
        borderData: FlBorderData(show: false),
        barGroups: groups,
      ),
    );
  }
}
