// lib/features/boat_owner/data/boat_owner_api_service.dart
//
// Central Dio wrapper for every /api/boat-owner endpoint.
// All methods throw on non-2xx so callers can catch a single exception type.

import 'package:dio/dio.dart';
import '../../../core/network/dio_client.dart';
import '../../../core/constants/api_constants.dart';

class BoatOwnerApiService {
  final Dio _dio;

  BoatOwnerApiService(DioClient client) : _dio = client.dio;

  // ── Dashboard ──────────────────────────────────────────────────────────────
  Future<Map<String, dynamic>> getDashboard() async {
    final res = await _dio.get(ApiConstants.boatOwnerDashboard);
    return res.data['data'] as Map<String, dynamic>;
  }

  // ── Bills ──────────────────────────────────────────────────────────────────
  Future<Map<String, dynamic>> getBills({
    String? boatId,
    String? fromDate,
    String? toDate,
    String? createdBy,
    int page = 1,
    int limit = 50,
  }) async {
    final res = await _dio.get(
      ApiConstants.boatOwnerBills,
      queryParameters: {
        if (boatId != null) 'boatId': boatId,
        if (fromDate != null) 'fromDate': fromDate,
        if (toDate != null) 'toDate': toDate,
        if (createdBy != null) 'createdBy': createdBy,
        'page': page,
        'limit': limit,
      },
    );
    return res.data as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> getBillById(String id) async {
    final res = await _dio.get('${ApiConstants.boatOwnerBills}/$id');
    return res.data['data'] as Map<String, dynamic>;
  }

  // ── Manual Ledger ──────────────────────────────────────────────────────────
  Future<Map<String, dynamic>> getLedgerSummary({
    String? boatId,
    String? fromDate,
    String? toDate,
  }) async {
    final res = await _dio.get(
      ApiConstants.boatOwnerLedgerSummary,
      queryParameters: {
        if (boatId != null) 'boatId': boatId,
        if (fromDate != null) 'fromDate': fromDate,
        if (toDate != null) 'toDate': toDate,
      },
    );
    return res.data['data'] as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> getLedgerEntries({
    String? boatId,
    String? type,
    String? category,
    String? fromDate,
    String? toDate,
    int page = 1,
    int limit = 50,
  }) async {
    final res = await _dio.get(
      ApiConstants.boatOwnerLedger,
      queryParameters: {
        if (boatId != null) 'boatId': boatId,
        if (type != null) 'type': type,
        if (category != null) 'category': category,
        if (fromDate != null) 'fromDate': fromDate,
        if (toDate != null) 'toDate': toDate,
        'page': page,
        'limit': limit,
      },
    );
    return res.data as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> createLedgerEntry(Map<String, dynamic> body) async {
    final res = await _dio.post(ApiConstants.boatOwnerLedger, data: body);
    return res.data['data'] as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> updateLedgerEntry(
      String id, Map<String, dynamic> body) async {
    final res =
        await _dio.put('${ApiConstants.boatOwnerLedger}/$id', data: body);
    return res.data['data'] as Map<String, dynamic>;
  }

  Future<void> deleteLedgerEntry(String id) async {
    await _dio.delete('${ApiConstants.boatOwnerLedger}/$id');
  }

  // ── Fishing Locations ──────────────────────────────────────────────────────
  Future<Map<String, dynamic>> saveFishingLocation(
      Map<String, dynamic> body) async {
    final res = await _dio.post(ApiConstants.boatOwnerFishingLocations, data: body);
    return res.data['data'] as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> getFishingLocations({
    String? boatId,
    String? fromDate,
    String? toDate,
    int page = 1,
    int limit = 50,
  }) async {
    final res = await _dio.get(
      ApiConstants.boatOwnerFishingLocations,
      queryParameters: {
        if (boatId != null) 'boatId': boatId,
        if (fromDate != null) 'fromDate': fromDate,
        if (toDate != null) 'toDate': toDate,
        'page': page,
        'limit': limit,
      },
    );
    return res.data as Map<String, dynamic>;
  }

  Future<void> deleteFishingLocation(String id) async {
    await _dio.delete('${ApiConstants.boatOwnerFishingLocations}/$id');
  }

  // ── Profile ────────────────────────────────────────────────────────────────
  Future<Map<String, dynamic>> getProfile() async {
    final res = await _dio.get(ApiConstants.boatOwnerProfile);
    return res.data['data'] as Map<String, dynamic>;
  }
}
