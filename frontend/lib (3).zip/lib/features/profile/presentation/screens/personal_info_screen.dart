import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_sizes.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../auth/presentation/providers/auth_provider.dart';

class PersonalInfoScreen extends ConsumerStatefulWidget {
  const PersonalInfoScreen({super.key});

  @override
  ConsumerState<PersonalInfoScreen> createState() => _PersonalInfoScreenState();
}

class _PersonalInfoScreenState extends ConsumerState<PersonalInfoScreen> {
  String _formatDate(DateTime? date) {
    if (date == null) return 'Not set';
    return DateFormat('dd-MMM-yyyy').format(date);
  }

  Future<void> _updateProfileField(String field, dynamic value) async {
    final success = await ref.read(authProvider.notifier).updateProfile({field: value});
    if (success && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${field.replaceAll(RegExp(r'(?=[A-Z])'), ' ').toUpperCase()} updated successfully')),
      );
    }
  }

  void _showEditFieldDialog(String fieldLabel, String fieldKey, String currentValue) {
    final ctrl = TextEditingController(text: currentValue);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Edit $fieldLabel'),
        content: TextField(
          controller: ctrl,
          decoration: InputDecoration(
            labelText: 'Enter new $fieldLabel',
            border: const OutlineInputBorder(),
          ),
          maxLines: fieldKey == 'aboutYou' || fieldKey == 'address' ? 3 : 1,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              _updateProfileField(fieldKey, ctrl.text.trim());
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  void _showEmergencyContactDialog(dynamic user) {
    final nameCtrl = TextEditingController(text: user.emergencyContactName ?? '');
    final relCtrl = TextEditingController(text: user.emergencyContactRelationship ?? '');
    final phoneCtrl = TextEditingController(text: user.emergencyContactPhone ?? '');

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Emergency Contact'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameCtrl,
              decoration: const InputDecoration(labelText: 'Contact Name'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: relCtrl,
              decoration: const InputDecoration(labelText: 'Relationship (e.g. Wife)'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: phoneCtrl,
              decoration: const InputDecoration(labelText: 'Phone Number'),
              keyboardType: TextInputType.phone,
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              ref.read(authProvider.notifier).updateProfile({
                'emergencyContactName': nameCtrl.text.trim(),
                'emergencyContactRelationship': relCtrl.text.trim(),
                'emergencyContactPhone': phoneCtrl.text.trim(),
              });
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authProvider);
    final user = authState.user;

    if (user == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Personal Information'),
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(AppSizes.p16),
        child: Column(
          children: [
            _buildSection(
              title: 'PERSONAL DETAILS',
              children: [
                _buildEditableRow(
                  icon: Icons.person_outline,
                  label: 'Full Name',
                  value: user.name,
                  onTap: () => _showEditFieldDialog('Name', 'name', user.name),
                ),
                const Divider(),
                _buildEditableRow(
                  icon: Icons.phone_outlined,
                  label: 'Phone Number',
                  value: user.phone,
                  onTap: () => _showEditFieldDialog('Phone Number', 'phone', user.phone),
                ),
                const Divider(),
                _buildEditableRow(
                  icon: Icons.email_outlined,
                  label: 'Email Address',
                  value: user.email,
                  onTap: () => _showEditFieldDialog('Email Address', 'email', user.email),
                ),
                const Divider(),
                _buildEditableRow(
                  icon: Icons.calendar_today_outlined,
                  label: 'Date of Birth',
                  value: _formatDate(user.dateOfBirth),
                  onTap: () async {
                    final picked = await showDatePicker(
                      context: context,
                      initialDate: user.dateOfBirth ?? DateTime(1990),
                      firstDate: DateTime(1900),
                      lastDate: DateTime.now(),
                    );
                    if (picked != null) {
                      _updateProfileField('dateOfBirth', picked.toIso8601String());
                    }
                  },
                ),
                const Divider(),
                _buildEditableRow(
                  icon: Icons.location_on_outlined,
                  label: 'Address',
                  value: (user.address != null && user.address!.isNotEmpty) ? user.address! : 'Not set',
                  onTap: () => _showEditFieldDialog('Address', 'address', user.address ?? ''),
                ),
                const Divider(),
                _buildEditableRow(
                  icon: Icons.emergency_outlined,
                  label: 'Emergency Contact Detail',
                  value: (user.emergencyContactName != null && user.emergencyContactName!.isNotEmpty)
                      ? '${user.emergencyContactName} (${user.emergencyContactRelationship ?? "Relation"}) — ${user.emergencyContactPhone}'
                      : 'Not configured',
                  onTap: () => _showEmergencyContactDialog(user),
                ),
              ],
            ),
            const SizedBox(height: AppSizes.p32),
          ],
        ),
      ),
    );
  }

  Widget _buildSection({required String title, required List<Widget> children}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(AppSizes.p16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: GoogleFonts.inter(
              color: AppColors.primary,
              fontWeight: FontWeight.bold,
              fontSize: 12,
              letterSpacing: 1.1,
            ),
          ),
          const SizedBox(height: 12),
          ...children,
        ],
      ),
    );
  }

  Widget _buildEditableRow({
    required IconData icon,
    required String label,
    required String value,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: AppColors.textHint, size: 20),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: AppTextStyles.caption.copyWith(color: AppColors.textSecondary),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    value,
                    style: AppTextStyles.bodyMedium.copyWith(fontWeight: FontWeight.w500),
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right_rounded, color: AppColors.textHint, size: 16),
          ],
        ),
      ),
    );
  }
}
